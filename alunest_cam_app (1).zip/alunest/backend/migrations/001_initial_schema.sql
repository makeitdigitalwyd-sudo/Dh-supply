-- AluNest CAM: Complete PostgreSQL Relational Schema (20 Tables)
-- Production target: PostgreSQL 15+

CREATE TABLE IF NOT EXISTS roles (
    id SERIAL PRIMARY KEY,
    name VARCHAR(64) UNIQUE NOT NULL,
    description TEXT,
    permissions_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role_id INTEGER NOT NULL REFERENCES roles(id),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    reset_token VARCHAR(255),
    reset_token_expires_at TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

CREATE TABLE IF NOT EXISTS customers (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    contact_email VARCHAR(255),
    contact_phone VARCHAR(64),
    company_code VARCHAR(64),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS projects (
    id SERIAL PRIMARY KEY,
    customer_id INTEGER REFERENCES customers(id),
    customer_name VARCHAR(255) NOT NULL,
    reference_code VARCHAR(128) NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT DEFAULT '',
    status VARCHAR(32) NOT NULL DEFAULT 'draft',
    created_by INTEGER REFERENCES users(id),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_projects_status ON projects(status);

CREATE TABLE IF NOT EXISTS dxf_files (
    id SERIAL PRIMARY KEY,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    original_filename VARCHAR(512) NOT NULL,
    storage_key VARCHAR(1024) NOT NULL,
    file_size_bytes BIGINT NOT NULL,
    sha256_hash VARCHAR(64) NOT NULL,
    dxf_version VARCHAR(32),
    units VARCHAR(32) NOT NULL DEFAULT 'mm',
    unit_scale_to_mm DOUBLE PRECISION NOT NULL DEFAULT 1.0,
    validation_status VARCHAR(32) NOT NULL DEFAULT 'pending',
    validation_report_json TEXT NOT NULL DEFAULT '{}',
    geometry_confirmed BOOLEAN NOT NULL DEFAULT FALSE,
    disconnected_mode VARCHAR(32) NOT NULL DEFAULT 'ask',
    uploaded_by INTEGER REFERENCES users(id),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_dxf_files_project ON dxf_files(project_id);

CREATE TABLE IF NOT EXISTS parts (
    id SERIAL PRIMARY KEY,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    dxf_file_id INTEGER NOT NULL REFERENCES dxf_files(id) ON DELETE CASCADE,
    part_name VARCHAR(255) NOT NULL,
    original_filename VARCHAR(512) NOT NULL,
    width_mm DOUBLE PRECISION NOT NULL,
    height_mm DOUBLE PRECISION NOT NULL,
    area_mm2 DOUBLE PRECISION NOT NULL,
    perimeter_mm DOUBLE PRECISION NOT NULL,
    internal_hole_count INTEGER NOT NULL DEFAULT 0,
    quantity INTEGER NOT NULL DEFAULT 1,
    allowed_rotations_json TEXT NOT NULL DEFAULT '[0, 90, 180, 270]',
    material_type VARCHAR(64) NOT NULL DEFAULT 'Aluminium',
    aluminium_grade VARCHAR(64) NOT NULL DEFAULT '5052-H32',
    thickness_mm DOUBLE PRECISION NOT NULL DEFAULT 2.0,
    validation_status VARCHAR(32) NOT NULL DEFAULT 'valid',
    geometry_wkt TEXT NOT NULL,
    svg_preview TEXT NOT NULL,
    is_library_part BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_parts_project ON parts(project_id);

CREATE TABLE IF NOT EXISTS part_instances (
    id SERIAL PRIMARY KEY,
    part_id INTEGER NOT NULL REFERENCES parts(id) ON DELETE CASCADE,
    instance_index INTEGER NOT NULL,
    label VARCHAR(128) NOT NULL
);

CREATE TABLE IF NOT EXISTS materials (
    id SERIAL PRIMARY KEY,
    name VARCHAR(128) NOT NULL,
    grade VARCHAR(64) NOT NULL,
    density_kg_m3 DOUBLE PRECISION NOT NULL DEFAULT 2700.0,
    cost_per_kg DOUBLE PRECISION NOT NULL DEFAULT 0.0
);

CREATE TABLE IF NOT EXISTS material_profiles (
    id SERIAL PRIMARY KEY,
    name VARCHAR(128) NOT NULL,
    material_id INTEGER REFERENCES materials(id),
    thickness_mm DOUBLE PRECISION NOT NULL,
    default_kerf_mm DOUBLE PRECISION NOT NULL DEFAULT 0.2,
    default_edge_margin_mm DOUBLE PRECISION NOT NULL DEFAULT 10.0,
    default_part_gap_mm DOUBLE PRECISION NOT NULL DEFAULT 3.0,
    grain_direction VARCHAR(32) DEFAULT 'none'
);

CREATE TABLE IF NOT EXISTS sheet_inventory (
    id SERIAL PRIMARY KEY,
    material_id INTEGER REFERENCES materials(id),
    grade VARCHAR(64) NOT NULL,
    thickness_mm DOUBLE PRECISION NOT NULL,
    width_mm DOUBLE PRECISION NOT NULL,
    height_mm DOUBLE PRECISION NOT NULL,
    quantity_available INTEGER NOT NULL DEFAULT 0,
    quantity_consumed INTEGER NOT NULL DEFAULT 0,
    cost_per_sheet DOUBLE PRECISION NOT NULL DEFAULT 0.0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS nesting_jobs (
    id SERIAL PRIMARY KEY,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    material_profile_id INTEGER REFERENCES material_profiles(id),
    sheet_width_mm DOUBLE PRECISION NOT NULL,
    sheet_height_mm DOUBLE PRECISION NOT NULL,
    edge_margin_mm DOUBLE PRECISION NOT NULL DEFAULT 10.0,
    part_gap_mm DOUBLE PRECISION NOT NULL DEFAULT 3.0,
    kerf_mm DOUBLE PRECISION NOT NULL DEFAULT 0.2,
    objective VARCHAR(64) NOT NULL DEFAULT 'max_utilization',
    status VARCHAR(32) NOT NULL DEFAULT 'pending',
    utilization_pct DOUBLE PRECISION DEFAULT 0.0,
    wastage_pct DOUBLE PRECISION DEFAULT 100.0,
    sheet_count INTEGER DEFAULT 0,
    is_approved BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS nesting_layouts (
    id SERIAL PRIMARY KEY,
    nesting_job_id INTEGER NOT NULL REFERENCES nesting_jobs(id) ON DELETE CASCADE,
    candidate_index INTEGER NOT NULL DEFAULT 1,
    sheet_index INTEGER NOT NULL DEFAULT 1,
    sheet_width_mm DOUBLE PRECISION NOT NULL,
    sheet_height_mm DOUBLE PRECISION NOT NULL,
    utilization_pct DOUBLE PRECISION NOT NULL DEFAULT 0.0,
    used_area_mm2 DOUBLE PRECISION NOT NULL DEFAULT 0.0,
    is_selected BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS layout_parts (
    id SERIAL PRIMARY KEY,
    nesting_layout_id INTEGER NOT NULL REFERENCES nesting_layouts(id) ON DELETE CASCADE,
    part_id INTEGER NOT NULL REFERENCES parts(id),
    instance_index INTEGER NOT NULL,
    pos_x_mm DOUBLE PRECISION NOT NULL,
    pos_y_mm DOUBLE PRECISION NOT NULL,
    rotation_deg DOUBLE PRECISION NOT NULL DEFAULT 0.0,
    is_locked BOOLEAN NOT NULL DEFAULT FALSE,
    placed_wkt TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS machine_profiles (
    id SERIAL PRIMARY KEY,
    manufacturer VARCHAR(128) NOT NULL,
    model VARCHAR(128) NOT NULL,
    controller VARCHAR(128) NOT NULL,
    file_extension VARCHAR(16) NOT NULL DEFAULT '.nc',
    units VARCHAR(16) NOT NULL DEFAULT 'mm',
    config_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS postprocessors (
    id SERIAL PRIMARY KEY,
    name VARCHAR(128) UNIQUE NOT NULL,
    controller VARCHAR(128) NOT NULL,
    version VARCHAR(32) NOT NULL DEFAULT '1.0',
    is_verified BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS toolpaths (
    id SERIAL PRIMARY KEY,
    nesting_job_id INTEGER NOT NULL REFERENCES nesting_jobs(id) ON DELETE CASCADE,
    machine_profile_id INTEGER REFERENCES machine_profiles(id),
    total_cut_distance_mm DOUBLE PRECISION NOT NULL DEFAULT 0.0,
    total_rapid_distance_mm DOUBLE PRECISION NOT NULL DEFAULT 0.0,
    pierce_count INTEGER NOT NULL DEFAULT 0,
    estimated_time_sec DOUBLE PRECISION NOT NULL DEFAULT 0.0,
    simulation_verified BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS cutting_operations (
    id SERIAL PRIMARY KEY,
    toolpath_id INTEGER NOT NULL REFERENCES toolpaths(id) ON DELETE CASCADE,
    sequence_index INTEGER NOT NULL,
    layout_part_id INTEGER REFERENCES layout_parts(id),
    contour_type VARCHAR(32) NOT NULL, -- 'internal' or 'external'
    pierce_x_mm DOUBLE PRECISION NOT NULL,
    pierce_y_mm DOUBLE PRECISION NOT NULL,
    cut_length_mm DOUBLE PRECISION NOT NULL,
    path_json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS export_files (
    id SERIAL PRIMARY KEY,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    nesting_job_id INTEGER REFERENCES nesting_jobs(id),
    export_type VARCHAR(32) NOT NULL, -- 'dxf', 'pdf', 'nc', 'zip'
    storage_key VARCHAR(1024) NOT NULL,
    version_number INTEGER NOT NULL DEFAULT 1,
    approved_by INTEGER REFERENCES users(id),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS remnants (
    id SERIAL PRIMARY KEY,
    remnant_code VARCHAR(64) UNIQUE NOT NULL,
    source_layout_id INTEGER REFERENCES nesting_layouts(id),
    grade VARCHAR(64) NOT NULL,
    thickness_mm DOUBLE PRECISION NOT NULL,
    width_mm DOUBLE PRECISION NOT NULL,
    height_mm DOUBLE PRECISION NOT NULL,
    area_mm2 DOUBLE PRECISION NOT NULL,
    geometry_wkt TEXT NOT NULL,
    is_available BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS job_history (
    id SERIAL PRIMARY KEY,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    user_id INTEGER REFERENCES users(id),
    action VARCHAR(128) NOT NULL,
    details_json TEXT NOT NULL DEFAULT '{}',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
