import os
import sys
import tempfile
import unittest
from pathlib import Path

TMP_DATA_DIR = tempfile.mkdtemp(prefix="alunest_test_")
os.environ["ALUNEST_DATA_DIR"] = TMP_DATA_DIR

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from fastapi.testclient import TestClient
from app.main import app
from app.db.database import init_db


def make_rect_dxf(w: float, h: float) -> bytes:
    return (
        f"0\nSECTION\n2\nHEADER\n9\n$INSUNITS\n70\n4\n0\nENDSEC\n"
        f"0\nSECTION\n2\nENTITIES\n"
        f"0\nLWPOLYLINE\n8\nCUT\n70\n1\n"
        f"10\n0\n20\n0\n10\n{w}\n20\n0\n10\n{w}\n20\n{h}\n10\n0\n20\n{h}\n"
        f"0\nENDSEC\n0\nEOF\n"
    ).encode("utf-8")


class TestPhase1API(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        init_db()
        cls.client = TestClient(app)

    def test_end_to_end_auth_project_dxf_parts(self):
        # 1. Register CAD Designer
        r = self.client.post("/api/auth/register", json={
            "email": "designer@alunest.test",
            "full_name": "Arun Menon",
            "password": "StrongPassword123",
            "role_name": "CAD Designer",
        })
        self.assertEqual(r.status_code, 201, r.text)
        token = r.json()["access_token"]
        headers = {"Authorization": f"Bearer {token}"}

        # 2. Create Project
        rp = self.client.post("/api/projects", headers=headers, json={
            "name": "Marine Panel Batch",
            "customer_name": "Cochin Shipyard",
            "reference_code": "CSL-2026-01",
            "description": "5052-H32 3mm brackets",
        })
        self.assertEqual(rp.status_code, 201, rp.text)
        pid = rp.json()["id"]

        # 3. Multi-DXF Upload
        files = [
            ("files", ("bracket_a.dxf", make_rect_dxf(120, 60), "application/dxf")),
            ("files", ("plate_b.dxf", make_rect_dxf(300, 150), "application/dxf")),
        ]
        ru = self.client.post(
            "/api/dxf/upload",
            headers=headers,
            data={"project_id": str(pid), "tolerance_mm": "0.1"},
            files=files,
        )
        self.assertEqual(ru.status_code, 201, ru.text)
        self.assertEqual(ru.json()["uploaded_count"], 2)

        # 4. List & Update Part Quantity
        parts = self.client.get(f"/api/parts?project_id={pid}", headers=headers).json()
        self.assertEqual(len(parts), 2)
        part_id = parts[0]["id"]
        patch_r = self.client.patch(
            f"/api/parts/{part_id}",
            headers=headers,
            json={"quantity": 15, "allowed_rotations": [0, 180], "aluminium_grade": "5052-H32", "thickness_mm": 3.0},
        )
        self.assertEqual(patch_r.status_code, 200, patch_r.text)
        self.assertEqual(patch_r.json()["quantity"], 15)
        self.assertEqual(patch_r.json()["allowed_rotations"], [0, 180])

        # 5. Dashboard summary
        dash = self.client.get("/api/dashboard/summary", headers=headers).json()
        self.assertEqual(dash["active_projects"], 1)
        self.assertEqual(dash["uploaded_dxfs"], 2)
        self.assertEqual(dash["total_part_instances"], 16)


if __name__ == "__main__":
    unittest.main()
