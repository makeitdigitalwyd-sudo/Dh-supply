import io
import os
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

TMP_DATA_DIR = tempfile.mkdtemp(prefix="alunest_full_test_")
os.environ["ALUNEST_DATA_DIR"] = TMP_DATA_DIR

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from fastapi.testclient import TestClient
from app.cad.geometry_engine import analyze_and_validate_dxf
from app.db.database import init_db
from app.main import app


def make_plate_with_hole_dxf(w: float, h: float, hole_r: float) -> bytes:
    cx, cy = w / 2.0, h / 2.0
    return (
        f"0\nSECTION\n2\nHEADER\n9\n$INSUNITS\n70\n4\n0\nENDSEC\n"
        f"0\nSECTION\n2\nENTITIES\n"
        f"0\nLWPOLYLINE\n8\nCUT\n70\n1\n"
        f"10\n0\n20\n0\n10\n{w}\n20\n0\n10\n{w}\n20\n{h}\n10\n0\n20\n{h}\n"
        f"0\nCIRCLE\n8\nHOLE\n10\n{cx}\n20\n{cy}\n40\n{hole_r}\n"
        f"0\nENDSEC\n0\nEOF\n"
    ).encode("utf-8")


class TestFullSystemEndToEnd(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        init_db()
        cls.client = TestClient(app)

    def test_full_manufacturing_workflow(self):
        # 1. Register Administrator
        r_auth = self.client.post("/api/auth/register", json={
            "email": "admin@alunest.test",
            "full_name": "Plant Admin",
            "password": "AdminPassword123",
            "role_name": "Administrator",
        })
        self.assertEqual(r_auth.status_code, 201, r_auth.text)
        headers = {"Authorization": f"Bearer {r_auth.json()['access_token']}"}

        # 2. Create Project & Upload 2 DXF parts
        r_proj = self.client.post("/api/projects", headers=headers, json={
            "name": "Full Suite Test Job",
            "customer_name": "AluFab Industries",
            "reference_code": "AF-2026-99",
        })
        self.assertEqual(r_proj.status_code, 201)
        pid = r_proj.json()["id"]

        r_up = self.client.post(
            "/api/dxf/upload",
            headers=headers,
            data={"project_id": str(pid), "tolerance_mm": "0.1"},
            files=[
                ("files", ("flange_with_hole.dxf", make_plate_with_hole_dxf(200, 100, 20), "application/dxf")),
                ("files", ("bracket_small.dxf", make_plate_with_hole_dxf(100, 80, 10), "application/dxf")),
            ],
        )
        self.assertEqual(r_up.status_code, 201, r_up.text)

        # Set quantities (4 flanges + 6 brackets = 10 instances)
        parts = self.client.get(f"/api/parts?project_id={pid}", headers=headers).json()
        for pt in parts:
            qty = 4 if "flange" in pt["part_name"] else 6
            self.client.patch(f"/api/parts/{pt['id']}", headers=headers, json={"quantity": qty})

        # 3. Run AUTO NEST on 1000 x 500 mm sheet (forces multi-sheet or tight packing)
        r_nest = self.client.post("/api/nesting/optimize", headers=headers, json={
            "project_id": pid,
            "sheet_width_mm": 600.0,
            "sheet_height_mm": 400.0,
            "edge_margin_mm": 10.0,
            "part_gap_mm": 4.0,
            "kerf_mm": 0.2,
            "objective": "max_utilization",
        })
        self.assertEqual(r_nest.status_code, 201, r_nest.text)
        nest_data = r_nest.json()
        job_id = nest_data["job"]["id"]
        self.assertGreaterEqual(nest_data["job"]["sheet_count"], 1)
        self.assertGreater(nest_data["job"]["utilization_pct"], 0.0)

        # Verify all 10 instances were placed
        best_cand = nest_data["candidates"][0]
        total_placed = sum(len(s["placed_parts"]) for s in best_cand["sheets"])
        self.assertEqual(total_placed, 10)

        # 4. Approve layout (runs strict boundary & clearance validation)
        r_app = self.client.post(f"/api/nesting/{job_id}/approve", headers=headers)
        self.assertEqual(r_app.status_code, 200, r_app.text)

        # 5. Generate Toolpath & verify internal-before-external ordering
        r_tp = self.client.post("/api/toolpath/generate", headers=headers, json={
            "nesting_job_id": job_id,
            "lead_in_mm": 3.0,
            "lead_out_mm": 1.0,
            "cutting_speed_mm_min": 3000.0,
            "pierce_time_sec": 0.4,
        })
        self.assertEqual(r_tp.status_code, 201, r_tp.text)
        ops = r_tp.json()["operations"]
        # 10 parts * (1 internal hole + 1 external perimeter) = 20 operations
        self.assertEqual(len(ops), 20)

        # Check invariant: for every layout_part_id, internal sequence_index < external sequence_index
        by_part = {}
        for op in ops:
            by_part.setdefault(op["layout_part_id"], {})[op["contour_type"]] = op["sequence_index"]
        for lp_id, seqs in by_part.items():
            self.assertLess(seqs["internal"], seqs["external"], f"Part {lp_id} cut external before internal!")

        # 6. Verify NC Export safety gate: must FAIL before simulation, SUCCEED after simulation
        r_nc_blocked = self.client.post("/api/export/nc", headers=headers, json={"nesting_job_id": job_id})
        self.assertEqual(r_nc_blocked.status_code, 400)

        r_sim = self.client.post(f"/api/toolpath/{job_id}/simulate", headers=headers)
        self.assertEqual(r_sim.status_code, 200)

        r_nc_ok = self.client.post("/api/export/nc", headers=headers, json={"nesting_job_id": job_id})
        self.assertEqual(r_nc_ok.status_code, 200, r_nc_ok.text)
        nc_dl = self.client.get(r_nc_ok.json()["download_url"], headers=headers)
        self.assertIn(b"G21 (METRIC MM)", nc_dl.content)

        # 7. Export DXF & re-parse to verify dimensional accuracy
        r_dxf = self.client.post("/api/export/dxf", headers=headers, json={"nesting_job_id": job_id})
        self.assertEqual(r_dxf.status_code, 200, r_dxf.text)
        dxf_bytes = self.client.get(r_dxf.json()["download_url"], headers=headers).content
        re_parsed = analyze_and_validate_dxf(dxf_bytes, disconnected_mode="split_parts")
        self.assertNotEqual(re_parsed.status, "invalid")
        self.assertGreaterEqual(len(re_parsed.extracted_parts), 2)

        # 8. Export PDF & verify PDF header
        r_pdf = self.client.post("/api/export/pdf", headers=headers, json={"nesting_job_id": job_id})
        self.assertEqual(r_pdf.status_code, 200, r_pdf.text)
        pdf_bytes = self.client.get(r_pdf.json()["download_url"], headers=headers).content
        self.assertTrue(pdf_bytes.startswith(b"%PDF-"))

        # 9. Export ZIP package
        r_zip = self.client.get(f"/api/export/{job_id}/zip", headers=headers)
        self.assertEqual(r_zip.status_code, 200)
        with zipfile.ZipFile(io.BytesIO(r_zip.content)) as zf:
            names = zf.namelist()
            self.assertTrue(any(n.endswith(".dxf") for n in names))
            self.assertTrue(any(n.endswith(".pdf") for n in names))
            self.assertTrue(any(n.endswith(".nc") for n in names))

        # 10. Cost Calculator
        r_cost = self.client.post("/api/cost/calculate", headers=headers, json={
            "nesting_job_id": job_id,
            "sheet_cost": 100.0,
            "machine_hourly_rate": 60.0,
            "pierce_cost_each": 0.1,
        })
        self.assertEqual(r_cost.status_code, 200, r_cost.text)
        cost = r_cost.json()
        self.assertEqual(cost["total_components_nested"], 10)
        self.assertGreater(cost["total_production_cost"], 0.0)


if __name__ == "__main__":
    unittest.main()
