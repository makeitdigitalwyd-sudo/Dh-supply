import math
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.cad.geometry_engine import analyze_and_validate_dxf


def make_dxf(entities_body: str, insunits: int = 4) -> bytes:
    return (
        f"0\nSECTION\n2\nHEADER\n"
        f"9\n$ACADVER\n1\nAC1027\n"
        f"9\n$INSUNITS\n70\n{insunits}\n"
        f"0\nENDSEC\n"
        f"0\nSECTION\n2\nENTITIES\n"
        f"{entities_body}"
        f"0\nENDSEC\n0\nEOF\n"
    ).encode("utf-8")


class TestDXFGeometryEngine(unittest.TestCase):
    def test_rectangular_lwpolyline(self):
        # 200 x 100 mm rectangle
        dxf = make_dxf(
            "0\nLWPOLYLINE\n8\nCUT\n70\n1\n"
            "10\n0\n20\n0\n10\n200\n20\n0\n10\n200\n20\n100\n10\n0\n20\n100\n"
        )
        rep = analyze_and_validate_dxf(dxf)
        self.assertEqual(rep.status, "valid")
        self.assertEqual(len(rep.extracted_parts), 1)
        p = rep.extracted_parts[0]
        self.assertAlmostEqual(p.width_mm, 200.0, places=2)
        self.assertAlmostEqual(p.height_mm, 100.0, places=2)
        self.assertAlmostEqual(p.area_mm2, 20000.0, places=1)
        self.assertAlmostEqual(p.perimeter_mm, 600.0, places=1)

    def test_irregular_concave_l_bracket_from_lines(self):
        # L-shape built from 6 individual LINE entities
        lines = [
            ((0, 0), (150, 0)),
            ((150, 0), (150, 40)),
            ((150, 40), (40, 40)),
            ((40, 40), (40, 120)),
            ((40, 120), (0, 120)),
            ((0, 120), (0, 0)),
        ]
        body = "".join(
            f"0\nLINE\n8\n0\n10\n{x1}\n20\n{y1}\n11\n{x2}\n21\n{y2}\n"
            for (x1, y1), (x2, y2) in lines
        )
        rep = analyze_and_validate_dxf(make_dxf(body))
        self.assertEqual(rep.status, "valid")
        p = rep.extracted_parts[0]
        # Area = 150*40 + 40*80 = 6000 + 3200 = 9200 mm2
        self.assertAlmostEqual(p.area_mm2, 9200.0, places=1)
        self.assertAlmostEqual(p.width_mm, 150.0, places=2)
        self.assertAlmostEqual(p.height_mm, 120.0, places=2)

    def test_circle_and_internal_hole(self):
        # Outer 100x100 square with centered R=20mm circular hole
        body = (
            "0\nLWPOLYLINE\n8\nOUTER\n70\n1\n"
            "10\n0\n20\n0\n10\n100\n20\n0\n10\n100\n20\n100\n10\n0\n20\n100\n"
            "0\nCIRCLE\n8\nHOLE\n10\n50\n20\n50\n40\n20\n"
        )
        rep = analyze_and_validate_dxf(make_dxf(body), tolerance_mm=0.05)
        self.assertEqual(rep.status, "valid")
        p = rep.extracted_parts[0]
        self.assertEqual(p.internal_hole_count, 1)
        expected_area = 10000.0 - math.pi * 20.0 * 20.0
        self.assertAlmostEqual(p.area_mm2, expected_area, delta=25.0)

    def test_arcs_chained_with_lines_slot(self):
        # Rounded slot: length 100 between centers, radius 20 -> total width 140, height 40
        body = (
            "0\nLINE\n8\n0\n10\n0\n20\n20\n11\n100\n21\n20\n"
            "0\nARC\n8\n0\n10\n100\n20\n0\n40\n20\n50\n270\n51\n90\n"
            "0\nLINE\n8\n0\n10\n100\n20\n-20\n11\n0\n21\n-20\n"
            "0\nARC\n8\n0\n10\n0\n20\n0\n40\n20\n50\n90\n51\n270\n"
        )
        rep = analyze_and_validate_dxf(make_dxf(body), tolerance_mm=0.05)
        self.assertEqual(rep.status, "valid")
        p = rep.extracted_parts[0]
        self.assertAlmostEqual(p.width_mm, 140.0, delta=0.2)
        self.assertAlmostEqual(p.height_mm, 40.0, delta=0.2)

    def test_disconnected_shapes_require_confirmation(self):
        body = (
            "0\nCIRCLE\n8\n0\n10\n20\n20\n20\n40\n15\n"
            "0\nCIRCLE\n8\n0\n10\n120\n20\n20\n40\n25\n"
        )
        raw = make_dxf(body)
        rep_ask = analyze_and_validate_dxf(raw, disconnected_mode="ask")
        self.assertEqual(rep_ask.status, "needs_confirmation")
        self.assertTrue(rep_ask.requires_disconnected_confirmation)
        self.assertEqual(rep_ask.disconnected_shape_count, 2)

        rep_split = analyze_and_validate_dxf(raw, disconnected_mode="split_parts")
        self.assertEqual(rep_split.status, "valid")
        self.assertEqual(len(rep_split.extracted_parts), 2)

        rep_single = analyze_and_validate_dxf(raw, disconnected_mode="single_component")
        self.assertEqual(rep_single.status, "valid")
        self.assertEqual(len(rep_single.extracted_parts), 1)

    def test_open_contour_detected_as_invalid(self):
        body = (
            "0\nLINE\n8\n0\n10\n0\n20\n0\n11\n100\n21\n0\n"
            "0\nLINE\n8\n0\n10\n100\n20\n0\n11\n100\n21\n50\n"
        )
        rep = analyze_and_validate_dxf(make_dxf(body))
        self.assertEqual(rep.status, "invalid")
        self.assertGreater(rep.open_contour_count, 0)

    def test_self_intersecting_bowtie_detected(self):
        body = (
            "0\nLWPOLYLINE\n8\n0\n70\n1\n"
            "10\n0\n20\n0\n10\n100\n20\n100\n10\n100\n20\n0\n10\n0\n20\n100\n"
        )
        rep = analyze_and_validate_dxf(make_dxf(body))
        self.assertEqual(rep.status, "invalid")
        self.assertGreater(rep.self_intersection_count, 0)

    def test_duplicate_lines_detected(self):
        body = (
            "0\nLINE\n8\n0\n10\n0\n20\n0\n11\n50\n21\n0\n"
            "0\nLINE\n8\n0\n10\n0\n20\n0\n11\n50\n21\n0\n"  # duplicate
            "0\nLINE\n8\n0\n10\n50\n20\n0\n11\n50\n21\n50\n"
            "0\nLINE\n8\n0\n10\n50\n20\n50\n11\n0\n21\n50\n"
            "0\nLINE\n8\n0\n10\n0\n20\n50\n11\n0\n21\n0\n"
        )
        rep = analyze_and_validate_dxf(make_dxf(body))
        self.assertEqual(rep.duplicate_line_count, 1)
        self.assertEqual(rep.status, "warning")
        self.assertAlmostEqual(rep.extracted_parts[0].area_mm2, 2500.0, places=1)

    def test_inches_unit_conversion(self):
        # 2 x 1 inch rectangle -> 50.8 x 25.4 mm
        body = (
            "0\nLWPOLYLINE\n8\n0\n70\n1\n"
            "10\n0\n20\n0\n10\n2\n20\n0\n10\n2\n20\n1\n10\n0\n20\n1\n"
        )
        rep = analyze_and_validate_dxf(make_dxf(body, insunits=1))
        self.assertEqual(rep.units, "inches")
        self.assertAlmostEqual(rep.extracted_parts[0].width_mm, 50.8, places=2)
        self.assertAlmostEqual(rep.extracted_parts[0].height_mm, 25.4, places=2)


if __name__ == "__main__":
    unittest.main()
