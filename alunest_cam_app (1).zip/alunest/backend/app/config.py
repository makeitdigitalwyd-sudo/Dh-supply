import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.getenv("ALUNEST_DATA_DIR", str(BASE_DIR / "data")))
STORAGE_DIR = DATA_DIR / "object_storage"
DB_PATH = DATA_DIR / "alunest.db"

JWT_SECRET = os.getenv("ALUNEST_JWT_SECRET", "alunest-dev-secret-change-in-production")
JWT_EXPIRY_SECONDS = int(os.getenv("ALUNEST_JWT_EXPIRY", "86400"))

DEFAULT_CURVE_TOLERANCE_MM = 0.1
MAX_UPLOAD_SIZE_BYTES = 50 * 1024 * 1024  # 50 MB per DXF
