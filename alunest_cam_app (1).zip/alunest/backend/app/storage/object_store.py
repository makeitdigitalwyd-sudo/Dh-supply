import hashlib
import uuid
from pathlib import Path
from typing import Tuple

from app.config import STORAGE_DIR


class ObjectStorage:
    """Persistent S3-compatible key-based object storage abstraction (local filesystem backend)."""

    def __init__(self, root_dir: Path | None = None):
        self.root_dir = root_dir or STORAGE_DIR
        self.root_dir.mkdir(parents=True, exist_ok=True)

    def put_bytes(self, key_prefix: str, filename: str, data: bytes) -> Tuple[str, str, int]:
        safe_name = Path(filename).name.replace(" ", "_")
        storage_key = f"{key_prefix}/{uuid.uuid4().hex}_{safe_name}"
        dest = self.root_dir / storage_key
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
        sha256 = hashlib.sha256(data).hexdigest()
        return storage_key, sha256, len(data)

    def get_bytes(self, storage_key: str) -> bytes:
        target = self.root_dir / storage_key
        if not target.exists():
            raise FileNotFoundError(f"Object not found for key: {storage_key}")
        return target.read_bytes()

    def delete(self, storage_key: str) -> None:
        target = self.root_dir / storage_key
        if target.exists():
            target.unlink()


object_store = ObjectStorage()
