from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

INSUNITS_TO_MM = {
    0: ("unitless (assumed mm)", 1.0),
    1: ("inches", 25.4),
    2: ("feet", 304.8),
    4: ("mm", 1.0),
    5: ("cm", 10.0),
    6: ("m", 1000.0),
}


@dataclass
class DXFEntity:
    etype: str
    layer: str = "0"
    data: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ParsedDXF:
    dxf_version: str = "UNKNOWN"
    units: str = "mm"
    unit_scale_to_mm: float = 1.0
    entities: List[DXFEntity] = field(default_factory=list)
    blocks: Dict[str, List[DXFEntity]] = field(default_factory=dict)
    unsupported_entities: List[Dict[str, str]] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)


SUPPORTED_TYPES = {"LINE", "LWPOLYLINE", "POLYLINE", "ARC", "CIRCLE", "ELLIPSE", "SPLINE", "HATCH", "INSERT"}
IGNORED_NON_CUT_TYPES = {"POINT", "TEXT", "MTEXT", "DIMENSION", "LEADER", "ATTDEF", "ATTRIB", "VIEWPORT"}


def _iter_pairs(text: str) -> List[Tuple[int, str]]:
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    pairs: List[Tuple[int, str]] = []
    i = 0
    n = len(lines)
    while i + 1 < n:
        code_str = lines[i].strip()
        val_str = lines[i + 1].strip()
        if code_str == "":
            i += 2
            continue
        try:
            code = int(code_str)
        except ValueError:
            i += 1
            continue
        pairs.append((code, val_str))
        i += 2
    return pairs


def _parse_entity_group(etype: str, items: List[Tuple[int, str]]) -> DXFEntity:
    layer = "0"
    for c, v in items:
        if c == 8:
            layer = v
            break

    if etype == "LINE":
        x1 = y1 = x2 = y2 = 0.0
        for c, v in items:
            if c == 10: x1 = float(v)
            elif c == 20: y1 = float(v)
            elif c == 11: x2 = float(v)
            elif c == 21: y2 = float(v)
        return DXFEntity("LINE", layer, {"start": (x1, y1), "end": (x2, y2)})

    if etype == "CIRCLE":
        cx = cy = r = 0.0
        for c, v in items:
            if c == 10: cx = float(v)
            elif c == 20: cy = float(v)
            elif c == 40: r = float(v)
        return DXFEntity("CIRCLE", layer, {"center": (cx, cy), "radius": r})

    if etype == "ARC":
        cx = cy = r = sa = ea = 0.0
        for c, v in items:
            if c == 10: cx = float(v)
            elif c == 20: cy = float(v)
            elif c == 40: r = float(v)
            elif c == 50: sa = float(v)
            elif c == 51: ea = float(v)
        return DXFEntity("ARC", layer, {"center": (cx, cy), "radius": r, "start_angle": sa, "end_angle": ea})

    if etype == "ELLIPSE":
        cx = cy = mx = my = 0.0
        ratio = 1.0
        sp = 0.0
        ep = 2.0 * math.pi
        for c, v in items:
            if c == 10: cx = float(v)
            elif c == 20: cy = float(v)
            elif c == 11: mx = float(v)
            elif c == 21: my = float(v)
            elif c == 40: ratio = float(v)
            elif c == 41: sp = float(v)
            elif c == 42: ep = float(v)
        return DXFEntity("ELLIPSE", layer, {
            "center": (cx, cy), "major_axis": (mx, my), "ratio": ratio, "start_param": sp, "end_param": ep
        })

    if etype == "LWPOLYLINE":
        flags = 0
        vertices: List[Tuple[float, float, float]] = []
        cur_x: Optional[float] = None
        cur_y: Optional[float] = None
        cur_bulge = 0.0
        for c, v in items:
            if c == 70:
                flags = int(v)
            elif c == 10:
                if cur_x is not None and cur_y is not None:
                    vertices.append((cur_x, cur_y, cur_bulge))
                cur_x = float(v)
                cur_y = None
                cur_bulge = 0.0
            elif c == 20:
                cur_y = float(v)
            elif c == 42:
                cur_bulge = float(v)
        if cur_x is not None and cur_y is not None:
            vertices.append((cur_x, cur_y, cur_bulge))
        return DXFEntity("LWPOLYLINE", layer, {"vertices": vertices, "closed": bool(flags & 1)})

    if etype == "SPLINE":
        flags = 0
        degree = 3
        knots: List[float] = []
        control_pts: List[List[float]] = []
        fit_pts: List[List[float]] = []
        for c, v in items:
            if c == 70: flags = int(v)
            elif c == 71: degree = int(v)
            elif c == 40: knots.append(float(v))
            elif c == 10: control_pts.append([float(v), 0.0])
            elif c == 20 and control_pts: control_pts[-1][1] = float(v)
            elif c == 11: fit_pts.append([float(v), 0.0])
            elif c == 21 and fit_pts: fit_pts[-1][1] = float(v)
        return DXFEntity("SPLINE", layer, {
            "degree": degree,
            "knots": knots,
            "control_points": [tuple(p) for p in control_pts],
            "fit_points": [tuple(p) for p in fit_pts],
            "closed": bool(flags & 1),
        })

    if etype == "INSERT":
        block_name = ""
        x = y = 0.0
        xs = ys = 1.0
        rot = 0.0
        for c, v in items:
            if c == 2: block_name = v
            elif c == 10: x = float(v)
            elif c == 20: y = float(v)
            elif c == 41: xs = float(v)
            elif c == 42: ys = float(v)
            elif c == 50: rot = float(v)
        return DXFEntity("INSERT", layer, {
            "block": block_name, "pos": (x, y), "scale": (xs, ys), "rotation": rot
        })

    if etype == "HATCH":
        # Extract simple polyline boundary vertices if present in HATCH
        pts: List[List[float]] = []
        for c, v in items:
            if c == 10:
                pts.append([float(v), 0.0])
            elif c == 20 and pts:
                pts[-1][1] = float(v)
        return DXFEntity("HATCH", layer, {"points": [tuple(p) for p in pts]})

    return DXFEntity(etype, layer, {})


def parse_dxf_bytes(raw_bytes: bytes) -> ParsedDXF:
    result = ParsedDXF()
    # Reject binary DXF clearly rather than crashing
    if raw_bytes.startswith(b"AutoCAD Binary DXF"):
        result.errors.append("Binary DXF format is not supported in offline mode; please save as ASCII DXF (R2000-R2018).")
        return result

    try:
        text = raw_bytes.decode("utf-8")
    except UnicodeDecodeError:
        text = raw_bytes.decode("latin-1", errors="replace")

    pairs = _iter_pairs(text)
    if not pairs:
        result.errors.append("Empty or invalid DXF file: no group code pairs found.")
        return result

    # Walk sections
    i = 0
    n = len(pairs)
    while i < n:
        code, val = pairs[i]
        if code == 0 and val == "SECTION":
            if i + 1 < n and pairs[i + 1][0] == 2:
                sec_name = pairs[i + 1][1]
                i += 2
                if sec_name == "HEADER":
                    i = _parse_header(pairs, i, result)
                    continue
                elif sec_name == "BLOCKS":
                    i = _parse_blocks(pairs, i, result)
                    continue
                elif sec_name == "ENTITIES":
                    i = _parse_entities_section(pairs, i, result)
                    continue
        i += 1

    # Expand INSERT blocks recursively (with cycle guard)
    expanded: List[DXFEntity] = []
    for ent in result.entities:
        if ent.etype == "INSERT":
            expanded.extend(_expand_insert(ent, result.blocks, depth=0))
        else:
            expanded.append(ent)
    result.entities = expanded
    return result


def _parse_header(pairs: List[Tuple[int, str]], i: int, result: ParsedDXF) -> int:
    n = len(pairs)
    current_var: Optional[str] = None
    while i < n:
        c, v = pairs[i]
        if c == 0 and v == "ENDSEC":
            return i + 1
        if c == 9:
            current_var = v
        elif current_var == "$ACADVER" and c == 1:
            result.dxf_version = v
        elif current_var == "$INSUNITS" and c == 70:
            try:
                unit_code = int(v)
                u_name, u_scale = INSUNITS_TO_MM.get(unit_code, (f"code_{unit_code} (assumed mm)", 1.0))
                result.units = u_name
                result.unit_scale_to_mm = u_scale
            except ValueError:
                pass
        i += 1
    return i


def _parse_entity_stream(pairs: List[Tuple[int, str]], i: int, stop_vals: set[str]) -> Tuple[List[DXFEntity], List[Dict[str, str]], int]:
    entities: List[DXFEntity] = []
    unsupported: List[Dict[str, str]] = []
    n = len(pairs)

    while i < n:
        c, v = pairs[i]
        if c == 0 and v in stop_vals:
            return entities, unsupported, i

        if c == 0:
            etype = v
            i += 1
            items: List[Tuple[int, str]] = []
            while i < n and pairs[i][0] != 0:
                items.append(pairs[i])
                i += 1

            if etype == "POLYLINE":
                flags = 0
                layer = "0"
                for ic, iv in items:
                    if ic == 70: flags = int(iv)
                    elif ic == 8: layer = iv
                verts: List[Tuple[float, float, float]] = []
                while i < n:
                    vc, vv = pairs[i]
                    if vc == 0 and vv == "SEQEND":
                        i += 1
                        while i < n and pairs[i][0] != 0:
                            i += 1
                        break
                    if vc == 0 and vv == "VERTEX":
                        i += 1
                        vx = vy = vb = 0.0
                        while i < n and pairs[i][0] != 0:
                            vc2, vv2 = pairs[i]
                            if vc2 == 10: vx = float(vv2)
                            elif vc2 == 20: vy = float(vv2)
                            elif vc2 == 42: vb = float(vv2)
                            i += 1
                        verts.append((vx, vy, vb))
                    else:
                        i += 1
                entities.append(DXFEntity("LWPOLYLINE", layer, {"vertices": verts, "closed": bool(flags & 1)}))
                continue

            if etype in SUPPORTED_TYPES:
                entities.append(_parse_entity_group(etype, items))
            elif etype not in IGNORED_NON_CUT_TYPES:
                unsupported.append({"type": etype, "layer": next((iv for ic, iv in items if ic == 8), "0")})
            continue
        i += 1

    return entities, unsupported, i


def _parse_blocks(pairs: List[Tuple[int, str]], i: int, result: ParsedDXF) -> int:
    n = len(pairs)
    while i < n:
        c, v = pairs[i]
        if c == 0 and v == "ENDSEC":
            return i + 1
        if c == 0 and v == "BLOCK":
            i += 1
            block_name = ""
            while i < n and pairs[i][0] != 0:
                if pairs[i][0] == 2:
                    block_name = pairs[i][1]
                i += 1
            ents, unsup, i = _parse_entity_stream(pairs, i, {"ENDBLK"})
            if block_name:
                result.blocks[block_name] = ents
            result.unsupported_entities.extend(unsup)
            if i < n and pairs[i][1] == "ENDBLK":
                i += 1
                while i < n and pairs[i][0] != 0:
                    i += 1
            continue
        i += 1
    return i


def _parse_entities_section(pairs: List[Tuple[int, str]], i: int, result: ParsedDXF) -> int:
    ents, unsup, next_i = _parse_entity_stream(pairs, i, {"ENDSEC"})
    result.entities.extend(ents)
    result.unsupported_entities.extend(unsup)
    if next_i < len(pairs) and pairs[next_i][1] == "ENDSEC":
        return next_i + 1
    return next_i


def _transform_pt(pt: Tuple[float, float], pos: Tuple[float, float], scale: Tuple[float, float], rot_deg: float) -> Tuple[float, float]:
    sx, sy = pt[0] * scale[0], pt[1] * scale[1]
    rad = math.radians(rot_deg)
    cos_a, sin_a = math.cos(rad), math.sin(rad)
    rx = sx * cos_a - sy * sin_a + pos[0]
    ry = sx * sin_a + sy * cos_a + pos[1]
    return (rx, ry)


def _expand_insert(ent: DXFEntity, blocks: Dict[str, List[DXFEntity]], depth: int) -> List[DXFEntity]:
    if depth > 8:
        return []
    bname = ent.data.get("block", "")
    b_ents = blocks.get(bname, [])
    pos = ent.data.get("pos", (0.0, 0.0))
    scale = ent.data.get("scale", (1.0, 1.0))
    rot = ent.data.get("rotation", 0.0)
    out: List[DXFEntity] = []
    for sub in b_ents:
        if sub.etype == "INSERT":
            out.extend(_expand_insert(sub, blocks, depth + 1))
        elif sub.etype == "LINE":
            out.append(DXFEntity("LINE", sub.layer, {
                "start": _transform_pt(sub.data["start"], pos, scale, rot),
                "end": _transform_pt(sub.data["end"], pos, scale, rot),
            }))
        elif sub.etype == "LWPOLYLINE":
            verts = [
                (*_transform_pt((vx, vy), pos, scale, rot), vb)
                for vx, vy, vb in sub.data["vertices"]
            ]
            out.append(DXFEntity("LWPOLYLINE", sub.layer, {"vertices": verts, "closed": sub.data["closed"]}))
        elif sub.etype == "CIRCLE":
            c = _transform_pt(sub.data["center"], pos, scale, rot)
            r = sub.data["radius"] * abs(scale[0])
            out.append(DXFEntity("CIRCLE", sub.layer, {"center": c, "radius": r}))
        elif sub.etype == "ARC":
            c = _transform_pt(sub.data["center"], pos, scale, rot)
            r = sub.data["radius"] * abs(scale[0])
            out.append(DXFEntity("ARC", sub.layer, {
                "center": c, "radius": r,
                "start_angle": sub.data["start_angle"] + rot,
                "end_angle": sub.data["end_angle"] + rot,
            }))
    return out
