from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from shapely.geometry import LineString, MultiPolygon, Polygon
from shapely.ops import linemerge, polygonize, unary_union
from shapely.validation import explain_validity

from app.cad.dxf_parser import DXFEntity, ParsedDXF, parse_dxf_bytes

Pt = Tuple[float, float]


@dataclass
class ExtractedPartGeometry:
    part_suffix: str
    width_mm: float
    height_mm: float
    area_mm2: float
    perimeter_mm: float
    internal_hole_count: int
    geometry_wkt: str
    svg_preview: str


@dataclass
class ValidationReport:
    status: str  # 'valid', 'warning', 'invalid', 'needs_confirmation'
    dxf_version: str
    units: str
    unit_scale_to_mm: float
    entity_count: int
    closed_contour_count: int
    open_contour_count: int
    duplicate_line_count: int
    self_intersection_count: int
    overlapping_entity_count: int
    disconnected_shape_count: int
    requires_disconnected_confirmation: bool
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    unsupported_entities: List[Dict[str, str]] = field(default_factory=list)
    extracted_parts: List[ExtractedPartGeometry] = field(default_factory=list)


def _arc_segment_count(radius: float, sweep_rad: float, tol_mm: float) -> int:
    if radius <= 0 or tol_mm <= 0:
        return 16
    # Chord height error: tol = r * (1 - cos(dtheta / 2))
    ratio = max(-1.0, min(1.0, 1.0 - tol_mm / radius))
    dtheta = 2.0 * math.acos(ratio)
    if dtheta <= 1e-4:
        return 128
    steps = max(8, min(256, int(math.ceil(abs(sweep_rad) / dtheta))))
    return steps


def _discretize_bulge(p1: Pt, p2: Pt, bulge: float, tol_mm: float) -> List[Pt]:
    if abs(bulge) < 1e-9:
        return [p1, p2]
    dx = p2[0] - p1[0]
    dy = p2[1] - p1[1]
    chord = math.hypot(dx, dy)
    if chord < 1e-9:
        return [p1]
    theta = 4.0 * math.atan(bulge)
    radius = abs(chord / (2.0 * math.sin(theta / 2.0)))
    steps = _arc_segment_count(radius, theta, tol_mm)

    # Center of bulge arc
    mx, my = (p1[0] + p2[0]) / 2.0, (p1[1] + p2[1]) / 2.0
    sagitta = bulge * chord / 2.0
    dist_center = (chord / 2.0) / math.tan(theta / 2.0)
    nx, ny = -dy / chord, dx / chord
    cx = mx + nx * dist_center
    cy = my + ny * dist_center

    start_ang = math.atan2(p1[1] - cy, p1[0] - cx)
    pts: List[Pt] = [p1]
    for k in range(1, steps):
        ang = start_ang + theta * (k / steps)
        pts.append((cx + radius * math.cos(ang), cy + radius * math.sin(ang)))
    pts.append(p2)
    return pts


def _de_boor(k: int, x: float, t: List[float], c: List[Pt], p: int) -> Pt:
    d = [list(c[j + k - p]) for j in range(p + 1)]
    for r in range(1, p + 1):
        for j in range(p, r - 1, -1):
            denom = t[j + 1 + k - r] - t[j + k - p]
            alpha = 0.0 if abs(denom) < 1e-12 else (x - t[j + k - p]) / denom
            d[j][0] = (1.0 - alpha) * d[j - 1][0] + alpha * d[j][0]
            d[j][1] = (1.0 - alpha) * d[j - 1][1] + alpha * d[j][1]
    return (d[p][0], d[p][1])


def _discretize_spline(data: Dict[str, Any], scale: float, tol_mm: float) -> List[Pt]:
    ctrl = [(p[0] * scale, p[1] * scale) for p in data.get("control_points", [])]
    knots = data.get("knots", [])
    degree = data.get("degree", 3)
    if len(ctrl) >= degree + 1 and len(knots) >= len(ctrl) + degree + 1:
        t_min, t_max = knots[degree], knots[len(ctrl)]
        steps = max(24, min(200, len(ctrl) * 12))
        pts: List[Pt] = []
        for s in range(steps + 1):
            u = t_min + (t_max - t_min) * (s / steps)
            if s == steps:
                u = t_max - 1e-9
            # Find knot span k
            k = degree
            for idx in range(degree, len(ctrl)):
                if knots[idx] <= u < knots[idx + 1]:
                    k = idx
                    break
            pts.append(_de_boor(k, u, knots, ctrl, degree))
        if data.get("closed") and pts and math.hypot(pts[0][0] - pts[-1][0], pts[0][1] - pts[-1][1]) > 1e-4:
            pts.append(pts[0])
        return pts
    fit = [(p[0] * scale, p[1] * scale) for p in data.get("fit_points", [])]
    return fit if len(fit) >= 2 else ctrl


def _entity_to_polylines(ent: DXFEntity, scale: float, tol_mm: float) -> Tuple[List[List[Pt]], bool]:
    """Returns (list_of_point_chains, is_explicitly_closed_primitive)."""
    et = ent.etype
    d = ent.data
    if et == "LINE":
        p1 = (d["start"][0] * scale, d["start"][1] * scale)
        p2 = (d["end"][0] * scale, d["end"][1] * scale)
        return ([[p1, p2]], False)

    if et == "CIRCLE":
        cx, cy = d["center"][0] * scale, d["center"][1] * scale
        r = abs(d["radius"] * scale)
        if r <= 1e-6:
            return ([], False)
        steps = _arc_segment_count(r, 2.0 * math.pi, tol_mm)
        pts = [(cx + r * math.cos(2.0 * math.pi * k / steps), cy + r * math.sin(2.0 * math.pi * k / steps)) for k in range(steps)]
        pts.append(pts[0])
        return ([pts], True)

    if et == "ARC":
        cx, cy = d["center"][0] * scale, d["center"][1] * scale
        r = abs(d["radius"] * scale)
        sa = math.radians(d["start_angle"])
        ea = math.radians(d["end_angle"])
        if ea <= sa:
            ea += 2.0 * math.pi
        sweep = ea - sa
        steps = _arc_segment_count(r, sweep, tol_mm)
        pts = [(cx + r * math.cos(sa + sweep * k / steps), cy + r * math.sin(sa + sweep * k / steps)) for k in range(steps + 1)]
        return ([pts], False)

    if et == "ELLIPSE":
        cx, cy = d["center"][0] * scale, d["center"][1] * scale
        mx, my = d["major_axis"][0] * scale, d["major_axis"][1] * scale
        a = math.hypot(mx, my)
        b = a * d["ratio"]
        rot = math.atan2(my, mx)
        sp, ep = d["start_param"], d["end_param"]
        if ep <= sp:
            ep += 2.0 * math.pi
        sweep = ep - sp
        steps = _arc_segment_count(max(a, b), sweep, tol_mm)
        cos_r, sin_r = math.cos(rot), math.sin(rot)
        pts: List[Pt] = []
        for k in range(steps + 1):
            t = sp + sweep * k / steps
            lx, ly = a * math.cos(t), b * math.sin(t)
            pts.append((cx + lx * cos_r - ly * sin_r, cy + lx * sin_r + ly * cos_r))
        is_closed = abs(sweep - 2.0 * math.pi) < 1e-3
        if is_closed and pts:
            pts[-1] = pts[0]
        return ([pts], is_closed)

    if et == "LWPOLYLINE":
        raw_verts = [(vx * scale, vy * scale, vb) for vx, vy, vb in d.get("vertices", [])]
        if len(raw_verts) < 2:
            return ([], False)
        pts = []
        closed = d.get("closed", False)
        n = len(raw_verts)
        seg_count = n if closed else n - 1
        for i in range(seg_count):
            p1 = (raw_verts[i][0], raw_verts[i][1])
            bulge = raw_verts[i][2]
            p2 = (raw_verts[(i + 1) % n][0], raw_verts[(i + 1) % n][1])
            seg_pts = _discretize_bulge(p1, p2, bulge, tol_mm)
            if not pts:
                pts.extend(seg_pts)
            else:
                pts.extend(seg_pts[1:])
        if closed and pts and math.hypot(pts[0][0] - pts[-1][0], pts[0][1] - pts[-1][1]) > 1e-5:
            pts.append(pts[0])
        is_closed = closed or (len(pts) >= 4 and math.hypot(pts[0][0] - pts[-1][0], pts[0][1] - pts[-1][1]) < 0.05)
        return ([pts], is_closed)

    if et == "SPLINE":
        pts = _discretize_spline(d, scale, tol_mm)
        is_closed = len(pts) >= 4 and math.hypot(pts[0][0] - pts[-1][0], pts[0][1] - pts[-1][1]) < 0.05
        return ([pts], is_closed)

    if et == "HATCH":
        pts = [(p[0] * scale, p[1] * scale) for p in d.get("points", [])]
        if len(pts) >= 3:
            if math.hypot(pts[0][0] - pts[-1][0], pts[0][1] - pts[-1][1]) > 1e-5:
                pts.append(pts[0])
            return ([pts], True)

    return ([], False)


def _polygon_to_svg(geom: Polygon | MultiPolygon) -> str:
    minx, miny, maxx, maxy = geom.bounds
    w = max(maxx - minx, 1.0)
    h = max(maxy - miny, 1.0)
    pad = max(w, h) * 0.06
    vx = minx - pad
    vy = miny - pad
    vw = w + 2 * pad
    vh = h + 2 * pad

    polys = list(geom.geoms) if isinstance(geom, MultiPolygon) else [geom]
    paths: List[str] = []
    for p in polys:
        # SVG Y-axis points down; flip Y around (miny + maxy) so CAD orientation is preserved
        def fmt_ring(coords):
            cmds = []
            for idx, (x, y) in enumerate(coords):
                sy = (miny + maxy) - y
                cmds.append(f"{'M' if idx == 0 else 'L'}{x:.2f},{sy:.2f}")
            cmds.append("Z")
            return " ".join(cmds)

        d_str = fmt_ring(p.exterior.coords)
        for interior in p.interiors:
            d_str += " " + fmt_ring(interior.coords)
        paths.append(d_str)

    combined_d = " ".join(paths)
    stroke_w = max(vw, vh) * 0.008
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{vx:.2f} {vy:.2f} {vw:.2f} {vh:.2f}" '
        f'class="w-full h-full">'
        f'<path d="{combined_d}" fill="#0ea5e9" fill-opacity="0.22" fill-rule="evenodd" '
        f'stroke="#38bdf8" stroke-width="{stroke_w:.3f}" vector-effect="non-scaling-stroke"/>'
        f'</svg>'
    )


def _normalize_to_origin(geom: Polygon | MultiPolygon) -> Polygon | MultiPolygon:
    from shapely.affinity import translate
    minx, miny, _, _ = geom.bounds
    return translate(geom, xoff=-minx, yoff=-miny)


def _build_hierarchy(polygons: List[Polygon]) -> List[Polygon]:
    """Group closed rings into outer boundaries with their enclosed internal holes."""
    if not polygons:
        return []
    # Sort largest area first
    sorted_polys = sorted(polygons, key=lambda p: p.area, reverse=True)
    assigned_as_hole = [False] * len(sorted_polys)
    result_parts: List[Polygon] = []

    for i, outer in enumerate(sorted_polys):
        if assigned_as_hole[i]:
            continue
        holes = []
        for j in range(i + 1, len(sorted_polys)):
            if assigned_as_hole[j]:
                continue
            cand = sorted_polys[j]
            # Check if candidate lies strictly inside outer (or within tiny tolerance)
            if outer.buffer(1e-3).contains(cand):
                # Ensure it's a direct hole (not nested inside another hole of outer)
                nested_in_hole = any(h.buffer(1e-3).contains(cand) for h in holes)
                if not nested_in_hole:
                    holes.append(cand)
                    assigned_as_hole[j] = True
        part = Polygon(outer.exterior.coords, [h.exterior.coords for h in holes])
        if not part.is_valid:
            part = part.buffer(0)
        if isinstance(part, Polygon) and part.area > 1e-4:
            result_parts.append(part)
        elif isinstance(part, MultiPolygon):
            result_parts.extend([g for g in part.geoms if g.area > 1e-4])

    return result_parts


def _snap_segments(segments: List[LineString], tol: float = 1e-3) -> List[LineString]:
    anchors: List[Pt] = []
    def snap_pt(pt: Pt) -> Pt:
        for ax, ay in anchors:
            if math.hypot(pt[0] - ax, pt[1] - ay) <= tol:
                return (ax, ay)
        anchors.append(pt)
        return pt
    out: List[LineString] = []
    for seg in segments:
        coords = list(seg.coords)
        coords[0] = snap_pt((coords[0][0], coords[0][1]))
        coords[-1] = snap_pt((coords[-1][0], coords[-1][1]))
        out.append(LineString(coords))
    return out


def analyze_and_validate_dxf(
    raw_bytes: bytes,
    tolerance_mm: float = 0.1,
    disconnected_mode: str = "ask",  # 'ask' | 'split_parts' | 'single_component'
) -> ValidationReport:
    parsed: ParsedDXF = parse_dxf_bytes(raw_bytes)
    if parsed.errors:
        return ValidationReport(
            status="invalid",
            dxf_version=parsed.dxf_version,
            units=parsed.units,
            unit_scale_to_mm=parsed.unit_scale_to_mm,
            entity_count=0,
            closed_contour_count=0,
            open_contour_count=0,
            duplicate_line_count=0,
            self_intersection_count=0,
            overlapping_entity_count=0,
            disconnected_shape_count=0,
            requires_disconnected_confirmation=False,
            errors=parsed.errors,
            unsupported_entities=parsed.unsupported_entities,
        )

    scale = parsed.unit_scale_to_mm
    errors: List[str] = []
    warnings: List[str] = []

    if parsed.unsupported_entities:
        types = sorted({u["type"] for u in parsed.unsupported_entities})
        warnings.append(f"Detected unsupported CAD entities ({', '.join(types)}) — not silently converted.")

    closed_rings: List[Polygon] = []
    open_segments: List[LineString] = []
    seen_segment_keys: set[Tuple[Tuple[int, int], Tuple[int, int]]] = set()
    duplicate_line_count = 0
    overlapping_entity_count = 0
    self_intersection_count = 0

    for ent in parsed.entities:
        chains, is_closed_prim = _entity_to_polylines(ent, scale, tolerance_mm)
        for chain in chains:
            if len(chain) < 2:
                continue
            if is_closed_prim and len(chain) >= 4:
                poly = Polygon(chain)
                if not poly.is_valid:
                    self_intersection_count += 1
                    errors.append(f"Self-intersecting contour detected on layer '{ent.layer}': {explain_validity(poly)}")
                    continue
                if poly.area > 1e-4:
                    closed_rings.append(poly)
            else:
                # Check duplicate LINE segments
                if ent.etype == "LINE" and len(chain) == 2:
                    p1, p2 = chain[0], chain[1]
                    k1 = (round(p1[0] * 100), round(p1[1] * 100))
                    k2 = (round(p2[0] * 100), round(p2[1] * 100))
                    seg_key = (min(k1, k2), max(k1, k2))
                    if seg_key in seen_segment_keys:
                        duplicate_line_count += 1
                        continue
                    seen_segment_keys.add(seg_key)
                ls = LineString(chain)
                if ls.length > 1e-4:
                    open_segments.append(ls)

    if duplicate_line_count > 0:
        warnings.append(f"Detected {duplicate_line_count} duplicate line segment(s).")

    # Detect overlapping open segments
    for i in range(len(open_segments)):
        for j in range(i + 1, len(open_segments)):
            if open_segments[i].equals(open_segments[j]) or (
                open_segments[i].overlaps(open_segments[j]) and open_segments[i].intersection(open_segments[j]).length > 0.1
            ):
                overlapping_entity_count += 1
    if overlapping_entity_count > 0:
        warnings.append(f"Detected {overlapping_entity_count} overlapping entity pair(s).")

    # Attempt to chain open segments into closed contours via linemerge + polygonize
    unclosed_chains: List[LineString] = []
    if open_segments:
        merged = linemerge(_snap_segments(open_segments))
        merged_list = list(merged.geoms) if hasattr(merged, "geoms") else [merged]
        for seg in merged_list:
            coords = list(seg.coords)
            if len(coords) >= 4 and math.hypot(coords[0][0] - coords[-1][0], coords[0][1] - coords[-1][1]) <= 0.05:
                if coords[0] != coords[-1]:
                    coords.append(coords[0])
                poly = Polygon(coords)
                if not poly.is_valid:
                    self_intersection_count += 1
                    errors.append(f"Self-intersecting chained contour: {explain_validity(poly)}")
                elif poly.area > 1e-4:
                    closed_rings.append(poly)
            else:
                # Try polygonize for intersecting closed networks
                unclosed_chains.append(seg)

        if unclosed_chains:
            poly_candidates = list(polygonize(unclosed_chains))
            if poly_candidates:
                for pc in poly_candidates:
                    if pc.is_valid and pc.area > 1e-4:
                        closed_rings.append(pc)
                # Remaining edges not part of any polygon
                poly_boundary = unary_union([pc.boundary for pc in poly_candidates])
                remaining = [u for u in unclosed_chains if not poly_boundary.buffer(0.05).contains(u)]
                unclosed_chains = remaining

    open_contour_count = len(unclosed_chains)
    if open_contour_count > 0:
        errors.append(f"Detected {open_contour_count} open/unclosed contour(s) that cannot form a closed cut boundary.")

    if not closed_rings:
        errors.append("Missing outer boundary: no valid closed contours found in DXF.")
        return ValidationReport(
            status="invalid",
            dxf_version=parsed.dxf_version,
            units=parsed.units,
            unit_scale_to_mm=scale,
            entity_count=len(parsed.entities),
            closed_contour_count=0,
            open_contour_count=open_contour_count,
            duplicate_line_count=duplicate_line_count,
            self_intersection_count=self_intersection_count,
            overlapping_entity_count=overlapping_entity_count,
            disconnected_shape_count=0,
            requires_disconnected_confirmation=False,
            errors=errors,
            warnings=warnings,
            unsupported_entities=parsed.unsupported_entities,
        )

    part_polys = _build_hierarchy(closed_rings)
    disconnected_count = len(part_polys)
    requires_conf = disconnected_count > 1 and disconnected_mode == "ask"

    if requires_conf:
        warnings.append(
            f"Found {disconnected_count} disconnected outer shapes. Please confirm whether they represent separate parts or a single multi-island component."
        )

    extracted: List[ExtractedPartGeometry] = []
    if disconnected_mode == "single_component" and len(part_polys) > 1:
        mp = MultiPolygon(part_polys)
        norm = _normalize_to_origin(mp)
        minx, miny, maxx, maxy = norm.bounds
        holes = sum(len(p.interiors) for p in part_polys)
        extracted.append(ExtractedPartGeometry(
            part_suffix="",
            width_mm=round(maxx - minx, 3),
            height_mm=round(maxy - miny, 3),
            area_mm2=round(norm.area, 3),
            perimeter_mm=round(norm.length, 3),
            internal_hole_count=holes,
            geometry_wkt=norm.wkt,
            svg_preview=_polygon_to_svg(norm),
        ))
    else:
        for idx, p in enumerate(part_polys, start=1):
            norm = _normalize_to_origin(p)
            minx, miny, maxx, maxy = norm.bounds
            suffix = f"_part{idx}" if len(part_polys) > 1 else ""
            extracted.append(ExtractedPartGeometry(
                part_suffix=suffix,
                width_mm=round(maxx - minx, 3),
                height_mm=round(maxy - miny, 3),
                area_mm2=round(norm.area, 3),
                perimeter_mm=round(norm.length, 3),
                internal_hole_count=len(p.interiors),
                geometry_wkt=norm.wkt,
                svg_preview=_polygon_to_svg(norm),
            ))

    if errors:
        status = "invalid"
    elif requires_conf:
        status = "needs_confirmation"
    elif warnings:
        status = "warning"
    else:
        status = "valid"

    return ValidationReport(
        status=status,
        dxf_version=parsed.dxf_version,
        units=parsed.units,
        unit_scale_to_mm=scale,
        entity_count=len(parsed.entities),
        closed_contour_count=len(closed_rings),
        open_contour_count=open_contour_count,
        duplicate_line_count=duplicate_line_count,
        self_intersection_count=self_intersection_count,
        overlapping_entity_count=overlapping_entity_count,
        disconnected_shape_count=disconnected_count,
        requires_disconnected_confirmation=requires_conf,
        errors=errors,
        warnings=warnings,
        unsupported_entities=parsed.unsupported_entities,
        extracted_parts=extracted,
    )
