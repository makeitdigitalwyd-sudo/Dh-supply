import json
from typing import Any, Dict, Optional

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from app.auth.security import get_current_user, require_permission
from app.cam.toolpath import generate_optimized_toolpath
from app.db.database import get_db

router = APIRouter(prefix="/api/toolpath", tags=["Laser Cutting Toolpath & Simulation"])


class ToolpathGenerateRequest(BaseModel):
    nesting_job_id: int
    machine_profile_id: Optional[int] = None
    lead_in_mm: float = Field(default=3.0, ge=0.0, le=20.0)
    lead_out_mm: float = Field(default=1.0, ge=0.0, le=20.0)
    cutting_speed_mm_min: float = Field(default=3000.0, gt=0)
    rapid_speed_mm_min: float = Field(default=20000.0, gt=0)
    pierce_time_sec: float = Field(default=0.4, ge=0)
    thermal_spacing_weight: float = Field(default=0.35, ge=0)


@router.post("/generate", status_code=status.HTTP_201_CREATED)
def generate_toolpath(req: ToolpathGenerateRequest, user: Dict[str, Any] = Depends(require_permission("generate_toolpath"))):
    with get_db() as conn:
        job = conn.execute("SELECT * FROM nesting_jobs WHERE id = ?", (req.nesting_job_id,)).fetchone()
        if not job:
            raise HTTPException(status_code=404, detail="Nesting job not found")

        placed_rows = conn.execute(
            """
            SELECT lp.*, nl.sheet_index
            FROM layout_parts lp
            JOIN nesting_layouts nl ON lp.nesting_layout_id = nl.id
            WHERE nl.nesting_job_id = ? AND nl.is_selected = 1
            ORDER BY nl.sheet_index, lp.id
            """,
            (req.nesting_job_id,),
        ).fetchall()
        if not placed_rows:
            raise HTTPException(status_code=400, detail="No placed parts in selected nesting layout")

        tp = generate_optimized_toolpath(
            placed_parts=[dict(r) for r in placed_rows],
            kerf_mm=job["kerf_mm"],
            lead_in_mm=req.lead_in_mm,
            lead_out_mm=req.lead_out_mm,
            cutting_speed_mm_min=req.cutting_speed_mm_min,
            rapid_speed_mm_min=req.rapid_speed_mm_min,
            pierce_time_sec=req.pierce_time_sec,
            thermal_spacing_weight=req.thermal_spacing_weight,
        )

        conn.execute("DELETE FROM toolpaths WHERE nesting_job_id = ?", (req.nesting_job_id,))
        cur = conn.execute(
            """
            INSERT INTO toolpaths (
                nesting_job_id, machine_profile_id, total_cut_distance_mm,
                total_rapid_distance_mm, pierce_count, estimated_time_sec, simulation_verified
            ) VALUES (?, ?, ?, ?, ?, ?, 0)
            """,
            (
                req.nesting_job_id, req.machine_profile_id,
                tp.total_cut_distance_mm, tp.total_rapid_distance_mm,
                tp.pierce_count, tp.estimated_time_sec,
            ),
        )
        tp_id = cur.lastrowid

        for s in tp.steps:
            conn.execute(
                """
                INSERT INTO cutting_operations (
                    toolpath_id, sequence_index, layout_part_id, contour_type,
                    pierce_x_mm, pierce_y_mm, cut_length_mm, path_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    tp_id, s.sequence_index, s.layout_part_id, s.contour_type,
                    s.pierce_point[0], s.pierce_point[1], s.cut_length_mm,
                    json.dumps({
                        "sheet_index": s.sheet_index,
                        "rapid_from": s.rapid_from,
                        "pierce_point": s.pierce_point,
                        "lead_in_path": s.lead_in_path,
                        "cut_path": s.cut_path,
                        "lead_out_path": s.lead_out_path,
                        "rapid_length_mm": s.rapid_length_mm,
                    }),
                ),
            )
        conn.commit()
    return _load_toolpath_payload(req.nesting_job_id)


def _load_toolpath_payload(nesting_job_id: int) -> Dict[str, Any]:
    with get_db() as conn:
        tp = conn.execute("SELECT * FROM toolpaths WHERE nesting_job_id = ?", (nesting_job_id,)).fetchone()
        if not tp:
            raise HTTPException(status_code=404, detail="Toolpath not generated for this nesting job")
        ops = conn.execute(
            "SELECT * FROM cutting_operations WHERE toolpath_id = ? ORDER BY sequence_index",
            (tp["id"],),
        ).fetchall()
    steps = []
    for o in ops:
        od = dict(o)
        od["path"] = json.loads(od.pop("path_json"))
        steps.append(od)
    return {"toolpath": dict(tp), "operations": steps}


@router.get("/{nesting_job_id}")
def get_toolpath(nesting_job_id: int, user: Dict[str, Any] = Depends(get_current_user)):
    return _load_toolpath_payload(nesting_job_id)


@router.post("/{nesting_job_id}/simulate")
def verify_simulation(nesting_job_id: int, user: Dict[str, Any] = Depends(get_current_user)):
    with get_db() as conn:
        cur = conn.execute("UPDATE toolpaths SET simulation_verified = 1 WHERE nesting_job_id = ?", (nesting_job_id,))
        conn.commit()
        if cur.rowcount == 0:
            raise HTTPException(status_code=404, detail="Toolpath not found")
    payload = _load_toolpath_payload(nesting_job_id)
    payload["simulation_verified"] = True
    return payload
