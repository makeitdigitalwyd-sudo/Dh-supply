from typing import Any, Dict, Optional

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from app.auth.security import get_current_user, require_permission
from app.db.database import get_db

router = APIRouter(tags=["Materials, Inventory & Remnants"])


class MaterialCreate(BaseModel):
    name: str = "Aluminium"
    grade: str = "5052-H32"
    density_kg_m3: float = Field(default=2700.0, gt=0)
    cost_per_kg: float = Field(default=4.5, ge=0)


class MaterialProfileCreate(BaseModel):
    name: str
    material_id: Optional[int] = None
    thickness_mm: float = Field(..., gt=0)
    default_kerf_mm: float = Field(default=0.2, ge=0)
    default_edge_margin_mm: float = Field(default=10.0, ge=0)
    default_part_gap_mm: float = Field(default=3.0, ge=0)
    grain_direction: str = "none"


class SheetInventoryCreate(BaseModel):
    grade: str = "5052-H32"
    thickness_mm: float = Field(..., gt=0)
    width_mm: float = Field(..., gt=0)
    height_mm: float = Field(..., gt=0)
    quantity_available: int = Field(..., ge=0)
    cost_per_sheet: float = Field(default=0.0, ge=0)


class RemnantCreate(BaseModel):
    remnant_code: str
    source_layout_id: Optional[int] = None
    grade: str
    thickness_mm: float = Field(..., gt=0)
    width_mm: float = Field(..., gt=0)
    height_mm: float = Field(..., gt=0)
    geometry_wkt: str = ""


@router.post("/api/materials", status_code=status.HTTP_201_CREATED)
def create_material(req: MaterialCreate, user: Dict[str, Any] = Depends(require_permission("manage_inventory"))):
    with get_db() as conn:
        cur = conn.execute(
            "INSERT INTO materials (name, grade, density_kg_m3, cost_per_kg) VALUES (?, ?, ?, ?)",
            (req.name, req.grade, req.density_kg_m3, req.cost_per_kg),
        )
        conn.commit()
        return dict(conn.execute("SELECT * FROM materials WHERE id = ?", (cur.lastrowid,)).fetchone())


@router.get("/api/materials")
def list_materials(user: Dict[str, Any] = Depends(get_current_user)):
    with get_db() as conn:
        mats = [dict(r) for r in conn.execute("SELECT * FROM materials ORDER BY id DESC").fetchall()]
        profs = [dict(r) for r in conn.execute("SELECT * FROM material_profiles ORDER BY id DESC").fetchall()]
    return {"materials": mats, "profiles": profs}


@router.post("/api/materials/profiles", status_code=status.HTTP_201_CREATED)
def create_material_profile(req: MaterialProfileCreate, user: Dict[str, Any] = Depends(require_permission("manage_inventory"))):
    with get_db() as conn:
        cur = conn.execute(
            """
            INSERT INTO material_profiles (
                name, material_id, thickness_mm, default_kerf_mm,
                default_edge_margin_mm, default_part_gap_mm, grain_direction
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (req.name, req.material_id, req.thickness_mm, req.default_kerf_mm, req.default_edge_margin_mm, req.default_part_gap_mm, req.grain_direction),
        )
        conn.commit()
        return dict(conn.execute("SELECT * FROM material_profiles WHERE id = ?", (cur.lastrowid,)).fetchone())


@router.post("/api/inventory", status_code=status.HTTP_201_CREATED)
def add_sheet_inventory(req: SheetInventoryCreate, user: Dict[str, Any] = Depends(require_permission("manage_inventory"))):
    with get_db() as conn:
        cur = conn.execute(
            """
            INSERT INTO sheet_inventory (grade, thickness_mm, width_mm, height_mm, quantity_available, cost_per_sheet)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (req.grade, req.thickness_mm, req.width_mm, req.height_mm, req.quantity_available, req.cost_per_sheet),
        )
        conn.commit()
        return dict(conn.execute("SELECT * FROM sheet_inventory WHERE id = ?", (cur.lastrowid,)).fetchone())


@router.get("/api/inventory")
def list_sheet_inventory(user: Dict[str, Any] = Depends(get_current_user)):
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM sheet_inventory ORDER BY id DESC").fetchall()
        return [dict(r) for r in rows]


@router.post("/api/remnants", status_code=status.HTTP_201_CREATED)
def save_remnant(req: RemnantCreate, user: Dict[str, Any] = Depends(require_permission("manage_inventory"))):
    area = round(req.width_mm * req.height_mm, 2)
    wkt_val = req.geometry_wkt or f"POLYGON ((0 0, {req.width_mm} 0, {req.width_mm} {req.height_mm}, 0 {req.height_mm}, 0 0))"
    with get_db() as conn:
        existing = conn.execute("SELECT id FROM remnants WHERE remnant_code = ?", (req.remnant_code,)).fetchone()
        if existing:
            raise HTTPException(status_code=400, detail="Remnant code already exists")
        cur = conn.execute(
            """
            INSERT INTO remnants (remnant_code, source_layout_id, grade, thickness_mm, width_mm, height_mm, area_mm2, geometry_wkt)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (req.remnant_code, req.source_layout_id, req.grade, req.thickness_mm, req.width_mm, req.height_mm, area, wkt_val),
        )
        conn.commit()
        return dict(conn.execute("SELECT * FROM remnants WHERE id = ?", (cur.lastrowid,)).fetchone())


@router.get("/api/remnants")
def list_remnants(available_only: bool = True, user: Dict[str, Any] = Depends(get_current_user)):
    with get_db() as conn:
        if available_only:
            rows = conn.execute("SELECT * FROM remnants WHERE is_available = 1 ORDER BY id DESC").fetchall()
        else:
            rows = conn.execute("SELECT * FROM remnants ORDER BY id DESC").fetchall()
        return [dict(r) for r in rows]
