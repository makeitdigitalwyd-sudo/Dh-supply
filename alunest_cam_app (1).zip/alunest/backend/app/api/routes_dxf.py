import json
from pathlib import Path
from typing import Any, Dict, List

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile, status
from pydantic import BaseModel

from app.auth.security import get_current_user, require_permission
from app.cad.geometry_engine import ValidationReport, analyze_and_validate_dxf
from app.config import DEFAULT_CURVE_TOLERANCE_MM, MAX_UPLOAD_SIZE_BYTES
from app.db.database import get_db
from app.storage.object_store import object_store

router = APIRouter(prefix="/api/dxf", tags=["DXF Import & Validation"])


class ValidateConfirmRequest(BaseModel):
    disconnected_mode: str = "split_parts"  # 'split_parts' | 'single_component'
    tolerance_mm: float = DEFAULT_CURVE_TOLERANCE_MM


def _report_to_dict(rep: ValidationReport) -> Dict[str, Any]:
    return {
        "status": rep.status,
        "dxf_version": rep.dxf_version,
        "units": rep.units,
        "unit_scale_to_mm": rep.unit_scale_to_mm,
        "entity_count": rep.entity_count,
        "closed_contour_count": rep.closed_contour_count,
        "open_contour_count": rep.open_contour_count,
        "duplicate_line_count": rep.duplicate_line_count,
        "self_intersection_count": rep.self_intersection_count,
        "overlapping_entity_count": rep.overlapping_entity_count,
        "disconnected_shape_count": rep.disconnected_shape_count,
        "requires_disconnected_confirmation": rep.requires_disconnected_confirmation,
        "errors": rep.errors,
        "warnings": rep.warnings,
        "unsupported_entities": rep.unsupported_entities,
    }


def _persist_extracted_parts(
    conn,
    project_id: int,
    dxf_id: int,
    original_filename: str,
    rep: ValidationReport,
) -> List[Dict[str, Any]]:
    conn.execute("DELETE FROM parts WHERE dxf_file_id = ?", (dxf_id,))
    base_name = Path(original_filename).stem
    created_parts: List[Dict[str, Any]] = []
    if rep.status == "invalid":
        return created_parts

    for p in rep.extracted_parts:
        part_name = f"{base_name}{p.part_suffix}"
        cur = conn.execute(
            """
            INSERT INTO parts (
                project_id, dxf_file_id, part_name, original_filename,
                width_mm, height_mm, area_mm2, perimeter_mm,
                internal_hole_count, quantity, validation_status, geometry_wkt, svg_preview
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                project_id, dxf_id, part_name, original_filename,
                p.width_mm, p.height_mm, p.area_mm2, p.perimeter_mm,
                p.internal_hole_count, 1, rep.status, p.geometry_wkt, p.svg_preview,
            ),
        )
        row = conn.execute("SELECT * FROM parts WHERE id = ?", (cur.lastrowid,)).fetchone()
        created_parts.append(dict(row))
    return created_parts


@router.post("/upload", status_code=status.HTTP_201_CREATED)
async def upload_multiple_dxf(
    project_id: int = Form(...),
    tolerance_mm: float = Form(DEFAULT_CURVE_TOLERANCE_MM),
    files: List[UploadFile] = File(...),
    user: Dict[str, Any] = Depends(require_permission("upload_dxf")),
):
    with get_db() as conn:
        proj = conn.execute("SELECT id FROM projects WHERE id = ?", (project_id,)).fetchone()
        if not proj:
            raise HTTPException(status_code=404, detail="Project not found")

    results = []
    for f in files:
        raw = await f.read()
        if len(raw) > MAX_UPLOAD_SIZE_BYTES:
            raise HTTPException(status_code=400, detail=f"File {f.filename} exceeds 50 MB limit")

        storage_key, sha256, size_bytes = object_store.put_bytes(
            f"projects/{project_id}/dxf", f.filename or "upload.dxf", raw
        )
        rep = analyze_and_validate_dxf(raw, tolerance_mm=tolerance_mm, disconnected_mode="ask")
        rep_dict = _report_to_dict(rep)
        confirmed = 1 if (rep.status in ("valid", "warning") and not rep.requires_disconnected_confirmation) else 0

        with get_db() as conn:
            cur = conn.execute(
                """
                INSERT INTO dxf_files (
                    project_id, original_filename, storage_key, file_size_bytes, sha256_hash,
                    dxf_version, units, unit_scale_to_mm, validation_status, validation_report_json,
                    geometry_confirmed, disconnected_mode, uploaded_by
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    project_id, f.filename, storage_key, size_bytes, sha256,
                    rep.dxf_version, rep.units, rep.unit_scale_to_mm, rep.status,
                    json.dumps(rep_dict), confirmed, "ask", user["id"],
                ),
            )
            dxf_id = cur.lastrowid
            parts = _persist_extracted_parts(conn, project_id, dxf_id, f.filename or "upload.dxf", rep)
            conn.execute(
                "INSERT INTO job_history (project_id, user_id, action, details_json) VALUES (?, ?, ?, ?)",
                (project_id, user["id"], "dxf_uploaded", json.dumps({"filename": f.filename, "status": rep.status})),
            )
            conn.commit()
            dxf_row = dict(conn.execute("SELECT * FROM dxf_files WHERE id = ?", (dxf_id,)).fetchone())

        results.append({
            "dxf_file": dxf_row,
            "validation": rep_dict,
            "extracted_parts": parts,
        })

    return {"uploaded_count": len(results), "items": results}


@router.get("/{dxf_id}")
def get_dxf(dxf_id: int, user: Dict[str, Any] = Depends(get_current_user)):
    with get_db() as conn:
        row = conn.execute("SELECT * FROM dxf_files WHERE id = ?", (dxf_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="DXF file not found")
        parts = conn.execute("SELECT * FROM parts WHERE dxf_file_id = ?", (dxf_id,)).fetchall()
    d = dict(row)
    d["validation_report"] = json.loads(d.pop("validation_report_json", "{}"))
    return {"dxf_file": d, "parts": [dict(p) for p in parts]}


@router.post("/{dxf_id}/validate")
def validate_and_confirm_dxf(
    dxf_id: int,
    req: ValidateConfirmRequest,
    user: Dict[str, Any] = Depends(require_permission("upload_dxf")),
):
    if req.disconnected_mode not in ("split_parts", "single_component", "ask"):
        raise HTTPException(status_code=400, detail="disconnected_mode must be 'split_parts' or 'single_component'")
    with get_db() as conn:
        row = conn.execute("SELECT * FROM dxf_files WHERE id = ?", (dxf_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="DXF file not found")
        raw = object_store.get_bytes(row["storage_key"])
        rep = analyze_and_validate_dxf(raw, tolerance_mm=req.tolerance_mm, disconnected_mode=req.disconnected_mode)
        rep_dict = _report_to_dict(rep)
        confirmed = 1 if (rep.status in ("valid", "warning") and not rep.requires_disconnected_confirmation) else 0
        conn.execute(
            """
            UPDATE dxf_files
            SET validation_status = ?, validation_report_json = ?, geometry_confirmed = ?, disconnected_mode = ?
            WHERE id = ?
            """,
            (rep.status, json.dumps(rep_dict), confirmed, req.disconnected_mode, dxf_id),
        )
        parts = _persist_extracted_parts(conn, row["project_id"], dxf_id, row["original_filename"], rep)
        conn.commit()
    return {"validation": rep_dict, "geometry_confirmed": bool(confirmed), "parts": parts}


@router.delete("/{dxf_id}")
def delete_dxf(dxf_id: int, user: Dict[str, Any] = Depends(require_permission("upload_dxf"))):
    with get_db() as conn:
        row = conn.execute("SELECT storage_key FROM dxf_files WHERE id = ?", (dxf_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="DXF file not found")
        object_store.delete(row["storage_key"])
        conn.execute("DELETE FROM dxf_files WHERE id = ?", (dxf_id,))
        conn.commit()
    return {"deleted": True, "dxf_id": dxf_id}
