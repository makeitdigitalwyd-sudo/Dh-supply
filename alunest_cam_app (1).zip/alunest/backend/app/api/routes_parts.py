import json
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from app.auth.security import get_current_user, require_permission
from app.db.database import get_db

router = APIRouter(prefix="/api/parts", tags=["Parts Library"])


class PartUpdateRequest(BaseModel):
    part_name: Optional[str] = None
    quantity: Optional[int] = Field(default=None, ge=1, le=100000)
    allowed_rotations: Optional[List[int]] = None
    material_type: Optional[str] = None
    aluminium_grade: Optional[str] = None
    thickness_mm: Optional[float] = Field(default=None, gt=0)
    is_library_part: Optional[bool] = None


@router.get("")
def list_parts(
    project_id: Optional[int] = Query(default=None),
    library_only: bool = Query(default=False),
    user: Dict[str, Any] = Depends(get_current_user),
):
    with get_db() as conn:
        if project_id is not None:
            rows = conn.execute("SELECT * FROM parts WHERE project_id = ? ORDER BY id DESC", (project_id,)).fetchall()
        elif library_only:
            rows = conn.execute("SELECT * FROM parts WHERE is_library_part = 1 ORDER BY id DESC").fetchall()
        else:
            rows = conn.execute("SELECT * FROM parts ORDER BY id DESC").fetchall()
    out = []
    for r in rows:
        d = dict(r)
        d["allowed_rotations"] = json.loads(d.pop("allowed_rotations_json", "[0, 90, 180, 270]"))
        out.append(d)
    return out


@router.patch("/{part_id}")
def update_part(
    part_id: int,
    req: PartUpdateRequest,
    user: Dict[str, Any] = Depends(require_permission("edit_parts")),
):
    with get_db() as conn:
        row = conn.execute("SELECT * FROM parts WHERE id = ?", (part_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Part not found")
        updates = {}
        if req.part_name is not None: updates["part_name"] = req.part_name
        if req.quantity is not None: updates["quantity"] = req.quantity
        if req.allowed_rotations is not None: updates["allowed_rotations_json"] = json.dumps(req.allowed_rotations)
        if req.material_type is not None: updates["material_type"] = req.material_type
        if req.aluminium_grade is not None: updates["aluminium_grade"] = req.aluminium_grade
        if req.thickness_mm is not None: updates["thickness_mm"] = req.thickness_mm
        if req.is_library_part is not None: updates["is_library_part"] = 1 if req.is_library_part else 0

        if updates:
            set_clause = ", ".join(f"{k} = ?" for k in updates.keys())
            conn.execute(f"UPDATE parts SET {set_clause} WHERE id = ?", (*updates.values(), part_id))
            conn.commit()
        updated = dict(conn.execute("SELECT * FROM parts WHERE id = ?", (part_id,)).fetchone())
        updated["allowed_rotations"] = json.loads(updated.pop("allowed_rotations_json", "[0, 90, 180, 270]"))
        return updated


@router.delete("/{part_id}")
def delete_part(part_id: int, user: Dict[str, Any] = Depends(require_permission("edit_parts"))):
    with get_db() as conn:
        cur = conn.execute("DELETE FROM parts WHERE id = ?", (part_id,))
        conn.commit()
        if cur.rowcount == 0:
            raise HTTPException(status_code=404, detail="Part not found")
    return {"deleted": True, "part_id": part_id}
