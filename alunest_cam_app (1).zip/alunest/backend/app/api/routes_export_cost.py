import io
import json
import zipfile
from typing import Any, Dict

from fastapi import APIRouter, Depends, HTTPException, Response, status
from pydantic import BaseModel, Field

from app.auth.security import get_current_user, require_permission
from app.cam.dxf_exporter import export_sheet_to_dxf_bytes
from app.cam.postprocessor import POSTPROCESSOR_REGISTRY
from app.db.database import get_db
from app.nesting.engine import validate_sheet_placement
from app.reports.pdf_report import generate_production_pdf
from app.storage.object_store import object_store

router = APIRouter(tags=["Machine Profiles, Cost & Export Center"])


class MachineProfileCreate(BaseModel):
    manufacturer: str
    model: str
    controller: str
    file_extension: str = ".nc"
    units: str = "mm"
    config: Dict[str, Any] = Field(default_factory=dict)


class CostCalculateRequest(BaseModel):
    nesting_job_id: int
    sheet_cost: float = Field(..., ge=0)
    machine_hourly_rate: float = Field(..., ge=0)
    pierce_cost_each: float = Field(default=0.0, ge=0)


class ExportRequest(BaseModel):
    nesting_job_id: int
    machine_profile_id: int | None = None
    postprocessor_key: str = "reference_iso_6983"


@router.post("/api/machines", status_code=status.HTTP_201_CREATED)
def create_machine_profile(req: MachineProfileCreate, user: Dict[str, Any] = Depends(require_permission("manage_inventory"))):
    with get_db() as conn:
        cur = conn.execute(
            "INSERT INTO machine_profiles (manufacturer, model, controller, file_extension, units, config_json) VALUES (?, ?, ?, ?, ?, ?)",
            (req.manufacturer, req.model, req.controller, req.file_extension, req.units, json.dumps(req.config)),
        )
        conn.commit()
        return dict(conn.execute("SELECT * FROM machine_profiles WHERE id = ?", (cur.lastrowid,)).fetchone())


@router.get("/api/machines")
def list_machine_profiles(user: Dict[str, Any] = Depends(get_current_user)):
    with get_db() as conn:
        rows = [dict(r) for r in conn.execute("SELECT * FROM machine_profiles ORDER BY id DESC").fetchall()]
    return {
        "machines": rows,
        "postprocessors": [{"key": k, "name": v.name, "extension": v.file_extension} for k, v in POSTPROCESSOR_REGISTRY.items()],
    }


@router.post("/api/cost/calculate")
def calculate_job_cost(req: CostCalculateRequest, user: Dict[str, Any] = Depends(get_current_user)):
    with get_db() as conn:
        job = conn.execute("SELECT * FROM nesting_jobs WHERE id = ?", (req.nesting_job_id,)).fetchone()
        if not job:
            raise HTTPException(status_code=404, detail="Nesting job not found")
        tp = conn.execute("SELECT * FROM toolpaths WHERE nesting_job_id = ?", (req.nesting_job_id,)).fetchone()
        total_instances = conn.execute(
            """
            SELECT COUNT(*) FROM layout_parts lp
            JOIN nesting_layouts nl ON lp.nesting_layout_id = nl.id
            WHERE nl.nesting_job_id = ? AND nl.is_selected = 1
            """,
            (req.nesting_job_id,),
        ).fetchone()[0]
        usable_parts_area = conn.execute(
            """
            SELECT COALESCE(SUM(nl.used_area_mm2), 0.0)
            FROM nesting_layouts nl
            WHERE nl.nesting_job_id = ? AND nl.is_selected = 1
            """,
            (req.nesting_job_id,),
        ).fetchone()[0]

    sheet_count = max(job["sheet_count"], 1)
    gross_sheet_area = job["sheet_width_mm"] * job["sheet_height_mm"] * sheet_count
    usable_inner_w = max(job["sheet_width_mm"] - 2 * job["edge_margin_mm"], 0.0)
    usable_inner_h = max(job["sheet_height_mm"] - 2 * job["edge_margin_mm"], 0.0)
    usable_margin_area = usable_inner_w * usable_inner_h * sheet_count

    edge_margin_waste = max(gross_sheet_area - usable_margin_area, 0.0)
    skeleton_and_kerf_waste = max(usable_margin_area - usable_parts_area, 0.0)

    total_material_cost = round(sheet_count * req.sheet_cost, 2)
    est_hours = (tp["estimated_time_sec"] / 3600.0) if tp else 0.0
    pierces = tp["pierce_count"] if tp else 0
    machine_operating_cost = round(est_hours * req.machine_hourly_rate + pierces * req.pierce_cost_each, 2)
    total_production_cost = round(total_material_cost + machine_operating_cost, 2)
    cost_per_component = round(total_production_cost / total_instances, 2) if total_instances > 0 else 0.0

    return {
        "nesting_job_id": req.nesting_job_id,
        "sheet_count": sheet_count,
        "total_components_nested": total_instances,
        "gross_sheet_area_mm2": round(gross_sheet_area, 2),
        "usable_parts_area_mm2": round(usable_parts_area, 2),
        "edge_margin_waste_mm2": round(edge_margin_waste, 2),
        "skeleton_and_kerf_waste_mm2": round(skeleton_and_kerf_waste, 2),
        "geometric_utilization_pct": job["utilization_pct"],
        "material_wastage_pct": job["wastage_pct"],
        "total_material_cost": total_material_cost,
        "estimated_cutting_time_sec": tp["estimated_time_sec"] if tp else 0.0,
        "machine_operating_cost": machine_operating_cost,
        "total_production_cost": total_production_cost,
        "cost_per_component": cost_per_component,
    }


def _load_selected_sheets_and_parts(conn, job_id: int):
    job = dict(conn.execute("SELECT * FROM nesting_jobs WHERE id = ?", (job_id,)).fetchone() or {})
    if not job:
        raise HTTPException(status_code=404, detail="Nesting job not found")
    project = dict(conn.execute("SELECT * FROM projects WHERE id = ?", (job["project_id"],)).fetchone())
    layouts = [dict(r) for r in conn.execute(
        "SELECT * FROM nesting_layouts WHERE nesting_job_id = ? AND is_selected = 1 ORDER BY sheet_index",
        (job_id,),
    ).fetchall()]
    for l in layouts:
        l["placed_parts"] = [dict(r) for r in conn.execute(
            """
            SELECT lp.*, p.part_name
            FROM layout_parts lp
            JOIN parts p ON lp.part_id = p.id
            WHERE lp.nesting_layout_id = ?
            """,
            (l["id"],),
        ).fetchall()]
        v = validate_sheet_placement(
            l["placed_parts"], job["sheet_width_mm"], job["sheet_height_mm"],
            job["edge_margin_mm"], job["part_gap_mm"], job["kerf_mm"],
        )
        if not v["valid"]:
            raise HTTPException(status_code=422, detail={"message": "Cannot export invalid layout", "errors": v["errors"]})
    parts_summary = [dict(r) for r in conn.execute("SELECT * FROM parts WHERE project_id = ?", (job["project_id"],)).fetchall()]
    tp_row = conn.execute("SELECT * FROM toolpaths WHERE nesting_job_id = ?", (job_id,)).fetchone()
    tp = dict(tp_row) if tp_row else None
    return project, job, layouts, parts_summary, tp


def _save_export(conn, project_id: int, job_id: int, exp_type: str, filename: str, data: bytes, user_id: int) -> int:
    key, _, _ = object_store.put_bytes(f"projects/{project_id}/exports", filename, data)
    ver = conn.execute(
        "SELECT COALESCE(MAX(version_number), 0) + 1 FROM export_files WHERE nesting_job_id = ? AND export_type = ?",
        (job_id, exp_type),
    ).fetchone()[0]
    cur = conn.execute(
        "INSERT INTO export_files (project_id, nesting_job_id, export_type, storage_key, version_number, approved_by) VALUES (?, ?, ?, ?, ?, ?)",
        (project_id, job_id, exp_type, key, ver, user_id),
    )
    conn.commit()
    return cur.lastrowid


@router.post("/api/export/dxf")
def export_dxf(req: ExportRequest, user: Dict[str, Any] = Depends(require_permission("export_nc"))):
    with get_db() as conn:
        project, job, layouts, _, _ = _load_selected_sheets_and_parts(conn, req.nesting_job_id)
        if not layouts:
            raise HTTPException(status_code=400, detail="No selected sheets to export")
        dxf_bytes = export_sheet_to_dxf_bytes(layouts[0]["sheet_width_mm"], layouts[0]["sheet_height_mm"], layouts[0]["placed_parts"])
        exp_id = _save_export(conn, project["id"], job["id"], "dxf", f"job_{job['id']}_sheet1.dxf", dxf_bytes, user["id"])
    return {"export_id": exp_id, "filename": f"job_{job['id']}_sheet1.dxf", "download_url": f"/api/export/download/{exp_id}"}


@router.post("/api/export/pdf")
def export_pdf(req: ExportRequest, user: Dict[str, Any] = Depends(get_current_user)):
    with get_db() as conn:
        project, job, layouts, parts_summary, tp = _load_selected_sheets_and_parts(conn, req.nesting_job_id)
        pdf_bytes = generate_production_pdf(project, job, layouts, parts_summary, tp)
        exp_id = _save_export(conn, project["id"], job["id"], "pdf", f"job_{job['id']}_report.pdf", pdf_bytes, user["id"])
    return {"export_id": exp_id, "filename": f"job_{job['id']}_report.pdf", "download_url": f"/api/export/download/{exp_id}"}


@router.post("/api/export/nc")
def export_nc(req: ExportRequest, user: Dict[str, Any] = Depends(require_permission("export_nc"))):
    if req.postprocessor_key not in POSTPROCESSOR_REGISTRY:
        raise HTTPException(status_code=400, detail="Unknown postprocessor key")
    with get_db() as conn:
        project, job, _, _, tp = _load_selected_sheets_and_parts(conn, req.nesting_job_id)
        if not tp:
            raise HTTPException(status_code=400, detail="Generate toolpath before NC export")
        if not tp["simulation_verified"]:
            raise HTTPException(status_code=400, detail="Machine safety gate: run and verify 2D cutting simulation before NC export.")

        ops = []
        for r in conn.execute("SELECT * FROM cutting_operations WHERE toolpath_id = ? ORDER BY sequence_index", (tp["id"],)).fetchall():
            d = dict(r)
            d["path"] = json.loads(d.pop("path_json"))
            ops.append(d)

        machine = {"manufacturer": "Generic", "model": "Laser", "controller": "ISO-6983", "config_json": "{}"}
        if req.machine_profile_id:
            mr = conn.execute("SELECT * FROM machine_profiles WHERE id = ?", (req.machine_profile_id,)).fetchone()
            if mr:
                machine = dict(mr)

        post = POSTPROCESSOR_REGISTRY[req.postprocessor_key]
        nc_bytes = post.generate(job, machine, ops)
        fname = f"job_{job['id']}_program{post.file_extension}"
        exp_id = _save_export(conn, project["id"], job["id"], "nc", fname, nc_bytes, user["id"])
    return {"export_id": exp_id, "filename": fname, "download_url": f"/api/export/download/{exp_id}"}


@router.get("/api/export/{job_id}/zip")
def export_zip_package(job_id: int, user: Dict[str, Any] = Depends(require_permission("export_nc"))):
    with get_db() as conn:
        project, job, layouts, parts_summary, tp = _load_selected_sheets_and_parts(conn, job_id)
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            for s in layouts:
                dxf_b = export_sheet_to_dxf_bytes(s["sheet_width_mm"], s["sheet_height_mm"], s["placed_parts"])
                zf.writestr(f"sheet_{s['sheet_index']}.dxf", dxf_b)
            pdf_b = generate_production_pdf(project, job, layouts, parts_summary, tp)
            zf.writestr(f"production_report_job_{job_id}.pdf", pdf_b)
            if tp and tp["simulation_verified"]:
                ops = []
                for r in conn.execute("SELECT * FROM cutting_operations WHERE toolpath_id = ? ORDER BY sequence_index", (tp["id"],)).fetchall():
                    d = dict(r)
                    d["path"] = json.loads(d.pop("path_json"))
                    ops.append(d)
                nc_b = POSTPROCESSOR_REGISTRY["reference_iso_6983"].generate(job, {}, ops)
                zf.writestr(f"program_job_{job_id}.nc", nc_b)
        return Response(
            content=buf.getvalue(),
            media_type="application/zip",
            headers={"Content-Disposition": f"attachment; filename=alunest_job_{job_id}_package.zip"},
        )


@router.get("/api/export/download/{export_id}")
def download_export(export_id: int, user: Dict[str, Any] = Depends(get_current_user)):
    with get_db() as conn:
        row = conn.execute("SELECT * FROM export_files WHERE id = ?", (export_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Export file not found")
        data = object_store.get_bytes(row["storage_key"])
        fname = row["storage_key"].split("_", 1)[-1]
    return Response(
        content=data,
        media_type="application/octet-stream",
        headers={"Content-Disposition": f"attachment; filename={fname}"},
    )
