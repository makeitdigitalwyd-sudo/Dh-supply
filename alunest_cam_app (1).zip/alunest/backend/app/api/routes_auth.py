from datetime import datetime, timedelta, timezone
from typing import Any, Dict

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from app.auth.security import (
    create_access_token,
    generate_reset_token,
    get_current_user,
    hash_password,
    verify_password,
)
from app.db.database import get_db

router = APIRouter(prefix="/api/auth", tags=["Authentication"])


class RegisterRequest(BaseModel):
    email: str = Field(..., min_length=3)
    full_name: str = Field(..., min_length=2)
    password: str = Field(..., min_length=6)
    role_name: str = Field(default="CAD Designer")


class LoginRequest(BaseModel):
    email: str
    password: str


class PasswordRecoveryRequest(BaseModel):
    email: str


class PasswordResetRequest(BaseModel):
    token: str
    new_password: str = Field(..., min_length=6)


@router.get("/roles")
def list_roles():
    with get_db() as conn:
        rows = conn.execute("SELECT id, name, description FROM roles ORDER BY id").fetchall()
        return [dict(r) for r in rows]


@router.post("/register", status_code=status.HTTP_201_CREATED)
def register(req: RegisterRequest):
    with get_db() as conn:
        existing = conn.execute("SELECT id FROM users WHERE email = ?", (req.email.lower(),)).fetchone()
        if existing:
            raise HTTPException(status_code=400, detail="Email is already registered")
        role_row = conn.execute("SELECT id, name FROM roles WHERE name = ?", (req.role_name,)).fetchone()
        if not role_row:
            raise HTTPException(status_code=400, detail=f"Invalid role: {req.role_name}")

        pw_hash = hash_password(req.password)
        cur = conn.execute(
            "INSERT INTO users (email, full_name, password_hash, role_id) VALUES (?, ?, ?, ?)",
            (req.email.lower(), req.full_name, pw_hash, role_row["id"]),
        )
        conn.commit()
        user_id = cur.lastrowid
        token = create_access_token({"sub": user_id, "email": req.email.lower(), "role": role_row["name"]})
        return {
            "access_token": token,
            "token_type": "bearer",
            "user": {"id": user_id, "email": req.email.lower(), "full_name": req.full_name, "role": role_row["name"]},
        }


@router.post("/login")
def login(req: LoginRequest):
    with get_db() as conn:
        row = conn.execute(
            """
            SELECT u.id, u.email, u.full_name, u.password_hash, u.is_active, r.name AS role_name
            FROM users u
            JOIN roles r ON u.role_id = r.id
            WHERE u.email = ?
            """,
            (req.email.lower(),),
        ).fetchone()
    if not row or not verify_password(req.password, row["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    if not row["is_active"]:
        raise HTTPException(status_code=403, detail="User account is disabled")

    token = create_access_token({"sub": row["id"], "email": row["email"], "role": row["role_name"]})
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {"id": row["id"], "email": row["email"], "full_name": row["full_name"], "role": row["role_name"]},
    }


@router.get("/me")
def me(user: Dict[str, Any] = Depends(get_current_user)):
    return user


@router.post("/password-recovery")
def request_password_recovery(req: PasswordRecoveryRequest):
    token = generate_reset_token()
    expires = (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()
    with get_db() as conn:
        cur = conn.execute(
            "UPDATE users SET reset_token = ?, reset_token_expires_at = ? WHERE email = ?",
            (token, expires, req.email.lower()),
        )
        conn.commit()
        if cur.rowcount == 0:
            # Return generic message for security, plus token only in dev/test
            return {"message": "If the email exists, a recovery token has been issued."}
    return {"message": "Password recovery token generated.", "dev_reset_token": token}


@router.post("/password-reset")
def reset_password(req: PasswordResetRequest):
    with get_db() as conn:
        row = conn.execute(
            "SELECT id, reset_token_expires_at FROM users WHERE reset_token = ?",
            (req.token,),
        ).fetchone()
        if not row:
            raise HTTPException(status_code=400, detail="Invalid reset token")
        exp = datetime.fromisoformat(row["reset_token_expires_at"])
        if exp < datetime.now(timezone.utc):
            raise HTTPException(status_code=400, detail="Reset token has expired")
        conn.execute(
            "UPDATE users SET password_hash = ?, reset_token = NULL, reset_token_expires_at = NULL WHERE id = ?",
            (hash_password(req.new_password), row["id"]),
        )
        conn.commit()
    return {"message": "Password updated successfully."}
