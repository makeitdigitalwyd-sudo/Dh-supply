import json
from typing import Any, Dict

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from app.auth.security import get_current_user, require_permission
from app.db.database import get_db

router = APIRouter(tags=["Projects & Dashboard"])


class ProjectCreate(BaseModel):
    name: str = Field(..., min_length=2)
    customer_name: str = Field(..., min_length=1)
    reference_code: str = Field(..., min_length=1)
    description: str = ""


@router.get("/api/dashboard/summary")
def dashboard_summary(user: Dict[str, Any] = Depends(get_current_user)):
    with get_db() as conn:
        active_projects = conn.execute("SELECT COUNT(*) FROM projects WHERE status != 'archived'").fetchone()[0]
        total_parts = conn.execute("SELECT COUNT(*), COALESCE(SUM(quantity), 0) FROM parts").fetchone()
        dxf_count = conn.execute("SELECT COUNT(*) FROM dxf_files").fetchone()[0]
        recent_dxfs = conn.execute(
            "SELECT id, project_id, original_filename, units, validation_status, created_at FROM dxf_files ORDER BY id DESC LIMIT 8"
        ).fetchall()
        recent_history = conn.execute(
            "SELECT id, project_id, action, details_json, created_at FROM job_history ORDER BY id DESC LIMIT 10"
        ).fetchall()
    return {
        "active_projects": active_projects,
        "unique_parts": total_parts[0],
        "total_part_instances": total_parts[1],
        "uploaded_dxfs": dxf_count,
        "recent_dxf_uploads": [dict(r) for r in recent_dxfs],
        "recent_history": [dict(r) for r in recent_history],
    }


@router.post("/api/projects", status_code=status.HTTP_201_CREATED)
def create_project(req: ProjectCreate, user: Dict[str, Any] = Depends(require_permission("manage_projects"))):
    with get_db() as conn:
        cur = conn.execute(
            "INSERT INTO projects (customer_name, reference_code, name, description, created_by) VALUES (?, ?, ?, ?, ?)",
            (req.customer_name, req.reference_code, req.name, req.description, user["id"]),
        )
        pid = cur.lastrowid
        conn.execute(
            "INSERT INTO job_history (project_id, user_id, action, details_json) VALUES (?, ?, ?, ?)",
            (pid, user["id"], "project_created", json.dumps({"name": req.name, "reference": req.reference_code})),
        )
        conn.commit()
        row = conn.execute("SELECT * FROM projects WHERE id = ?", (pid,)).fetchone()
        return dict(row)


@router.get("/api/projects")
def list_projects(user: Dict[str, Any] = Depends(get_current_user)):
    with get_db() as conn:
        rows = conn.execute(
            """
            SELECT p.*,
                (SELECT COUNT(*) FROM dxf_files d WHERE d.project_id = p.id) AS dxf_count,
                (SELECT COUNT(*) FROM parts pt WHERE pt.project_id = p.id) AS part_count
            FROM projects p
            ORDER BY p.id DESC
            """
        ).fetchall()
        return [dict(r) for r in rows]


@router.get("/api/projects/{project_id}")
def get_project(project_id: int, user: Dict[str, Any] = Depends(get_current_user)):
    with get_db() as conn:
        row = conn.execute("SELECT * FROM projects WHERE id = ?", (project_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Project not found")
        dxfs = conn.execute("SELECT * FROM dxf_files WHERE project_id = ? ORDER BY id DESC", (project_id,)).fetchall()
        parts = conn.execute("SELECT * FROM parts WHERE project_id = ? ORDER BY id DESC", (project_id,)).fetchall()
        history = conn.execute("SELECT * FROM job_history WHERE project_id = ? ORDER BY id DESC LIMIT 20", (project_id,)).fetchall()
    return {
        "project": dict(row),
        "dxf_files": [dict(d) for d in dxfs],
        "parts": [dict(p) for p in parts],
        "history": [dict(h) for h in history],
    }


@router.post("/api/projects/{project_id}/duplicate", status_code=status.HTTP_201_CREATED)
def duplicate_project(project_id: int, user: Dict[str, Any] = Depends(require_permission("manage_projects"))):
    with get_db() as conn:
        src = conn.execute("SELECT * FROM projects WHERE id = ?", (project_id,)).fetchone()
        if not src:
            raise HTTPException(status_code=404, detail="Project not found")
        cur = conn.execute(
            "INSERT INTO projects (customer_name, reference_code, name, description, created_by) VALUES (?, ?, ?, ?, ?)",
            (src["customer_name"], f"{src['reference_code']}-COPY", f"{src['name']} (Copy)", src["description"], user["id"]),
        )
        new_pid = cur.lastrowid
        conn.execute(
            "INSERT INTO job_history (project_id, user_id, action, details_json) VALUES (?, ?, ?, ?)",
            (new_pid, user["id"], "project_duplicated", json.dumps({"source_project_id": project_id})),
        )
        conn.commit()
        row = conn.execute("SELECT * FROM projects WHERE id = ?", (new_pid,)).fetchone()
        return dict(row)
