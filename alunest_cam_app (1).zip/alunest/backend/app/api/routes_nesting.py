import json
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from shapely import wkt as shapely_wkt
from shapely.affinity import rotate, translate

from app.auth.security import get_current_user, require_permission
from app.db.database import get_db
from app.nesting.engine import (
    CandidateLayout,
    LockedPlacement,
    NestingPartInput,
    run_polygon_nesting,
    validate_sheet_placement,
)

router = APIRouter(prefix="/api/nesting", tags=["Automatic Nesting"])


class NestOptimizeRequest(BaseModel):
    project_id: int
    sheet_width_mm: float = Field(..., gt=0)
    sheet_height_mm: float = Field(..., gt=0)
    edge_margin_mm: float = Field(default=10.0, ge=0)
    part_gap_mm: float = Field(default=3.0, ge=0)
    kerf_mm: float = Field(default=0.2, ge=0)
    objective: str = Field(default="max_utilization")  # max_utilization | min_sheets | min_travel | balanced
    part_priorities: Dict[int, int] = Field(default_factory=dict)


class ManualPartEdit(BaseModel):
    layout_part_id: int
    pos_x_mm: Optional[float] = None
    pos_y_mm: Optional[float] = None
    rotation_deg: Optional[float] = None
    is_locked: Optional[bool] = None
    sheet_index: Optional[int] = None


class ManualPartsBatchRequest(BaseModel):
    edits: List[ManualPartEdit]


def _persist_candidates(conn, job_id: int, candidates: List[CandidateLayout]) -> None:
    conn.execute("DELETE FROM nesting_layouts WHERE nesting_job_id = ?", (job_id,))
    for cand in candidates:
        is_sel = 1 if cand.candidate_index == 1 else 0
        for s in cand.sheets:
            cur_l = conn.execute(
                """
                INSERT INTO nesting_layouts (
                    nesting_job_id, candidate_index, sheet_index,
                    sheet_width_mm, sheet_height_mm, utilization_pct, used_area_mm2, is_selected
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (job_id, cand.candidate_index, s.sheet_index, s.width_mm, s.height_mm, s.utilization_pct, s.used_area_mm2, is_sel),
            )
            layout_id = cur_l.lastrowid
            for pp in s.placed_parts:
                conn.execute(
                    """
                    INSERT INTO layout_parts (
                        nesting_layout_id, part_id, instance_index,
                        pos_x_mm, pos_y_mm, rotation_deg, is_locked, placed_wkt
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (layout_id, pp.part_id, pp.instance_index, pp.pos_x_mm, pp.pos_y_mm, pp.rotation_deg, 1 if pp.is_locked else 0, pp.geometry.wkt),
                )


def _load_job_payload(conn, job_id: int) -> Dict[str, Any]:
    job = conn.execute("SELECT * FROM nesting_jobs WHERE id = ?", (job_id,)).fetchone()
    if not job:
        raise HTTPException(status_code=404, detail="Nesting job not found")
    layouts = conn.execute(
        "SELECT * FROM nesting_layouts WHERE nesting_job_id = ? ORDER BY candidate_index, sheet_index",
        (job_id,),
    ).fetchall()

    candidates_map: Dict[int, Dict[str, Any]] = {}
    for l in layouts:
        ld = dict(l)
        c_idx = ld["candidate_index"]
        parts_rows = conn.execute(
            """
            SELECT lp.*, p.part_name, p.internal_hole_count, p.area_mm2
            FROM layout_parts lp
            JOIN parts p ON lp.part_id = p.id
            WHERE lp.nesting_layout_id = ?
            ORDER BY lp.id
            """,
            (ld["id"],),
        ).fetchall()
        placed_list = []
        for pr in parts_rows:
            pd = dict(pr)
            geom = shapely_wkt.loads(pd["placed_wkt"])
            pd["exterior"] = [[round(x, 2), round(y, 2)] for x, y in geom.exterior.coords] if geom.geom_type == "Polygon" else []
            pd["holes"] = [
                [[round(x, 2), round(y, 2)] for x, y in ring.coords]
                for ring in geom.interiors
            ] if geom.geom_type == "Polygon" else []
            placed_list.append(pd)
        ld["placed_parts"] = placed_list
        if c_idx not in candidates_map:
            candidates_map[c_idx] = {
                "candidate_index": c_idx,
                "is_selected": bool(ld["is_selected"]),
                "sheets": [],
            }
        candidates_map[c_idx]["sheets"].append(ld)

    return {
        "job": dict(job),
        "candidates": list(candidates_map.values()),
    }


@router.post("/optimize", status_code=status.HTTP_201_CREATED)
def optimize_nesting(req: NestOptimizeRequest, user: Dict[str, Any] = Depends(require_permission("run_nesting"))):
    with get_db() as conn:
        proj = conn.execute("SELECT id FROM projects WHERE id = ?", (req.project_id,)).fetchone()
        if not proj:
            raise HTTPException(status_code=404, detail="Project not found")
        part_rows = conn.execute(
            "SELECT * FROM parts WHERE project_id = ? AND validation_status != 'invalid'",
            (req.project_id,),
        ).fetchall()
        if not part_rows:
            raise HTTPException(status_code=400, detail="No valid extracted parts found for this project.")

        inputs: List[NestingPartInput] = []
        for r in part_rows:
            inputs.append(NestingPartInput(
                part_id=r["id"],
                part_name=r["part_name"],
                quantity=r["quantity"],
                allowed_rotations=json.loads(r["allowed_rotations_json"]),
                geometry=shapely_wkt.loads(r["geometry_wkt"]),
                priority=req.part_priorities.get(r["id"], 0),
            ))

        candidates = run_polygon_nesting(
            parts=inputs,
            sheet_width_mm=req.sheet_width_mm,
            sheet_height_mm=req.sheet_height_mm,
            edge_margin_mm=req.edge_margin_mm,
            part_gap_mm=req.part_gap_mm,
            kerf_mm=req.kerf_mm,
            objective=req.objective,
        )
        best = candidates[0]
        cur = conn.execute(
            """
            INSERT INTO nesting_jobs (
                project_id, sheet_width_mm, sheet_height_mm, edge_margin_mm,
                part_gap_mm, kerf_mm, objective, status, utilization_pct, wastage_pct, sheet_count
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                req.project_id, req.sheet_width_mm, req.sheet_height_mm, req.edge_margin_mm,
                req.part_gap_mm, req.kerf_mm, req.objective, "completed",
                best.utilization_pct, best.wastage_pct, best.sheet_count,
            ),
        )
        job_id = cur.lastrowid
        _persist_candidates(conn, job_id, candidates)
        conn.execute(
            "INSERT INTO job_history (project_id, user_id, action, details_json) VALUES (?, ?, ?, ?)",
            (req.project_id, user["id"], "nesting_completed", json.dumps({"job_id": job_id, "utilization_pct": best.utilization_pct, "sheets": best.sheet_count})),
        )
        conn.commit()
        payload = _load_job_payload(conn, job_id)
        payload["heuristic_note"] = "Results represent heuristic optimized candidates (not claimed mathematically optimal)."
        payload["remnant_suggestions"] = best.sheets[0].remnant_candidates if best.sheets else []
        return payload


@router.get("/{job_id}")
def get_nesting_job(job_id: int, user: Dict[str, Any] = Depends(get_current_user)):
    with get_db() as conn:
        return _load_job_payload(conn, job_id)


@router.post("/{job_id}/select-candidate/{candidate_index}")
def select_candidate(job_id: int, candidate_index: int, user: Dict[str, Any] = Depends(require_permission("run_nesting"))):
    with get_db() as conn:
        conn.execute("UPDATE nesting_layouts SET is_selected = 0 WHERE nesting_job_id = ?", (job_id,))
        cur = conn.execute(
            "UPDATE nesting_layouts SET is_selected = 1 WHERE nesting_job_id = ? AND candidate_index = ?",
            (job_id, candidate_index),
        )
        if cur.rowcount == 0:
            raise HTTPException(status_code=404, detail="Candidate not found")
        sheets = conn.execute(
            "SELECT sheet_width_mm, sheet_height_mm, used_area_mm2 FROM nesting_layouts WHERE nesting_job_id = ? AND candidate_index = ?",
            (job_id, candidate_index),
        ).fetchall()
        tot_area = sum(s["sheet_width_mm"] * s["sheet_height_mm"] for s in sheets)
        tot_used = sum(s["used_area_mm2"] for s in sheets)
        util = round((tot_used / tot_area) * 100.0, 2) if tot_area > 0 else 0.0
        conn.execute(
            "UPDATE nesting_jobs SET utilization_pct = ?, wastage_pct = ?, sheet_count = ? WHERE id = ?",
            (util, round(100.0 - util, 2), len(sheets), job_id),
        )
        conn.commit()
        return _load_job_payload(conn, job_id)


@router.patch("/{job_id}/parts")
def edit_layout_parts(job_id: int, req: ManualPartsBatchRequest, user: Dict[str, Any] = Depends(require_permission("run_nesting"))):
    with get_db() as conn:
        job = conn.execute("SELECT * FROM nesting_jobs WHERE id = ?", (job_id,)).fetchone()
        if not job:
            raise HTTPException(status_code=404, detail="Nesting job not found")

        affected_layout_ids = set()
        for ed in req.edits:
            lp = conn.execute(
                """
                SELECT lp.*, p.geometry_wkt
                FROM layout_parts lp
                JOIN parts p ON lp.part_id = p.id
                WHERE lp.id = ?
                """,
                (ed.layout_part_id,),
            ).fetchone()
            if not lp:
                raise HTTPException(status_code=404, detail=f"Layout part {ed.layout_part_id} not found")

            px = ed.pos_x_mm if ed.pos_x_mm is not None else lp["pos_x_mm"]
            py = ed.pos_y_mm if ed.pos_y_mm is not None else lp["pos_y_mm"]
            rot = ed.rotation_deg if ed.rotation_deg is not None else lp["rotation_deg"]
            locked = (1 if ed.is_locked else 0) if ed.is_locked is not None else lp["is_locked"]

            base_geom = shapely_wkt.loads(lp["geometry_wkt"])
            r_geom = rotate(base_geom, rot, origin="centroid", use_radians=False) if rot != 0 else base_geom
            minx, miny, _, _ = r_geom.bounds
            placed_geom = translate(r_geom, xoff=px - minx, yoff=py - miny)

            conn.execute(
                "UPDATE layout_parts SET pos_x_mm = ?, pos_y_mm = ?, rotation_deg = ?, is_locked = ?, placed_wkt = ? WHERE id = ?",
                (px, py, rot, locked, placed_geom.wkt, ed.layout_part_id),
            )
            affected_layout_ids.add(lp["nesting_layout_id"])

        validation_errors: List[str] = []
        for lid in affected_layout_ids:
            items = [dict(r) for r in conn.execute("SELECT id, placed_wkt FROM layout_parts WHERE nesting_layout_id = ?", (lid,)).fetchall()]
            v = validate_sheet_placement(
                items,
                job["sheet_width_mm"],
                job["sheet_height_mm"],
                job["edge_margin_mm"],
                job["part_gap_mm"],
                job["kerf_mm"],
            )
            validation_errors.extend(v["errors"])

        if validation_errors:
            conn.rollback()
            raise HTTPException(status_code=422, detail={"message": "Placement violates geometric constraints", "errors": validation_errors})

        conn.commit()
        return _load_job_payload(conn, job_id)


@router.post("/{job_id}/reoptimize")
def reoptimize_unlocked(job_id: int, user: Dict[str, Any] = Depends(require_permission("run_nesting"))):
    with get_db() as conn:
        job = conn.execute("SELECT * FROM nesting_jobs WHERE id = ?", (job_id,)).fetchone()
        if not job:
            raise HTTPException(status_code=404, detail="Nesting job not found")

        part_rows = conn.execute(
            "SELECT * FROM parts WHERE project_id = ? AND validation_status != 'invalid'",
            (job["project_id"],),
        ).fetchall()
        inputs = [
            NestingPartInput(
                part_id=r["id"],
                part_name=r["part_name"],
                quantity=r["quantity"],
                allowed_rotations=json.loads(r["allowed_rotations_json"]),
                geometry=shapely_wkt.loads(r["geometry_wkt"]),
            )
            for r in part_rows
        ]

        locked_rows = conn.execute(
            """
            SELECT lp.*, nl.sheet_index
            FROM layout_parts lp
            JOIN nesting_layouts nl ON lp.nesting_layout_id = nl.id
            WHERE nl.nesting_job_id = ? AND nl.is_selected = 1 AND lp.is_locked = 1
            """,
            (job_id,),
        ).fetchall()
        locked = [
            LockedPlacement(
                part_id=lr["part_id"],
                instance_index=lr["instance_index"],
                sheet_index=lr["sheet_index"],
                pos_x_mm=lr["pos_x_mm"],
                pos_y_mm=lr["pos_y_mm"],
                rotation_deg=lr["rotation_deg"],
                geometry=shapely_wkt.loads(lr["placed_wkt"]),
            )
            for lr in locked_rows
        ]

        candidates = run_polygon_nesting(
            parts=inputs,
            sheet_width_mm=job["sheet_width_mm"],
            sheet_height_mm=job["sheet_height_mm"],
            edge_margin_mm=job["edge_margin_mm"],
            part_gap_mm=job["part_gap_mm"],
            kerf_mm=job["kerf_mm"],
            objective=job["objective"],
            locked_placements=locked,
        )
        best = candidates[0]
        conn.execute(
            "UPDATE nesting_jobs SET utilization_pct = ?, wastage_pct = ?, sheet_count = ? WHERE id = ?",
            (best.utilization_pct, best.wastage_pct, best.sheet_count, job_id),
        )
        _persist_candidates(conn, job_id, candidates)
        conn.commit()
        return _load_job_payload(conn, job_id)


@router.post("/{job_id}/approve")
def approve_layout(job_id: int, user: Dict[str, Any] = Depends(require_permission("approve_layout"))):
    with get_db() as conn:
        job = conn.execute("SELECT * FROM nesting_jobs WHERE id = ?", (job_id,)).fetchone()
        if not job:
            raise HTTPException(status_code=404, detail="Nesting job not found")
        layouts = conn.execute(
            "SELECT id FROM nesting_layouts WHERE nesting_job_id = ? AND is_selected = 1",
            (job_id,),
        ).fetchall()
        for l in layouts:
            items = [dict(r) for r in conn.execute("SELECT id, placed_wkt FROM layout_parts WHERE nesting_layout_id = ?", (l["id"],)).fetchall()]
            v = validate_sheet_placement(
                items,
                job["sheet_width_mm"],
                job["sheet_height_mm"],
                job["edge_margin_mm"],
                job["part_gap_mm"],
                job["kerf_mm"],
            )
            if not v["valid"]:
                raise HTTPException(status_code=422, detail={"message": "Cannot approve invalid layout", "errors": v["errors"]})

        conn.execute("UPDATE nesting_jobs SET is_approved = 1, status = 'approved' WHERE id = ?", (job_id,))
        conn.commit()
    return {"approved": True, "job_id": job_id}
