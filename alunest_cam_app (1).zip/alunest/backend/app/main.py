from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse

from app.api.routes_auth import router as auth_router
from app.api.routes_dxf import router as dxf_router
from app.api.routes_export_cost import router as export_cost_router
from app.api.routes_materials import router as materials_router
from app.api.routes_nesting import router as nesting_router
from app.api.routes_parts import router as parts_router
from app.api.routes_projects import router as projects_router
from app.api.routes_toolpath import router as toolpath_router
from app.db.database import init_db

app = FastAPI(
    title="AluNest CAM — Aluminium Laser Cutting & Nesting System",
    version="1.0.0",
    description="Full CAD/CAM Nesting, Toolpath Optimization, 2D Laser Simulation & Production Export System",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def on_startup():
    init_db()


app.include_router(auth_router)
app.include_router(projects_router)
app.include_router(dxf_router)
app.include_router(parts_router)
app.include_router(materials_router)
app.include_router(nesting_router)
app.include_router(toolpath_router)
app.include_router(export_cost_router)

STATIC_INDEX = Path(__file__).resolve().parent / "static" / "index.html"


@app.get("/", include_in_schema=False)
def serve_ui():
    return FileResponse(str(STATIC_INDEX))


@app.get("/api/health")
def health():
    return {"status": "ok", "version": "1.0.0", "engine": "shapely-geos"}
