from __future__ import annotations

import json
from abc import ABC, abstractmethod
from typing import Any, Dict, List


class BasePostprocessor(ABC):
    """Abstract CNC Laser Postprocessor interface."""

    @property
    @abstractmethod
    def name(self) -> str:
        ...

    @property
    @abstractmethod
    def file_extension(self) -> str:
        ...

    @abstractmethod
    def generate(
        self,
        job_meta: Dict[str, Any],
        machine_profile: Dict[str, Any],
        operations: List[Dict[str, Any]],
    ) -> bytes:
        ...


class UniversalIntermediatePostprocessor(BasePostprocessor):
    name = "Universal Intermediate Toolpath (JSON)"
    file_extension = ".toolpath.json"

    def generate(self, job_meta: Dict[str, Any], machine_profile: Dict[str, Any], operations: List[Dict[str, Any]]) -> bytes:
        payload = {
            "format": "alunest-universal-toolpath-v1",
            "units": "mm",
            "job": job_meta,
            "machine_profile": machine_profile,
            "operations": operations,
        }
        return json.dumps(payload, indent=2).encode("utf-8")


class ReferenceISO6983Postprocessor(BasePostprocessor):
    """
    Reference ISO 6983 (G-Code) postprocessor.
    NOTE: Must be verified against the specific laser controller manual before production cutting.
    """
    name = "Reference ISO 6983 G-Code (Requires Controller Verification)"
    file_extension = ".nc"

    def generate(self, job_meta: Dict[str, Any], machine_profile: Dict[str, Any], operations: List[Dict[str, Any]]) -> bytes:
        cfg = json.loads(machine_profile.get("config_json", "{}") or "{}")
        laser_on = cfg.get("laser_on", "M03")
        laser_off = cfg.get("laser_off", "M05")
        pierce_cmd = cfg.get("pierce_cmd", "G04 P0.4")
        feed_rate = cfg.get("feed_rate", 3000)

        lines = [
            "%",
            f"(ALUNEST REFERENCE ISO-6983 NC - VERIFY ON {machine_profile.get('manufacturer', 'GENERIC')} {machine_profile.get('controller', 'ISO')} BEFORE RUN)",
            f"(JOB ID: {job_meta.get('id')} | SHEET: {job_meta.get('sheet_width_mm')}x{job_meta.get('sheet_height_mm')} mm)",
            "G21 (METRIC MM)",
            "G90 (ABSOLUTE COORDINATES)",
            laser_off,
        ]

        for op in operations:
            path = op["path"]
            px, py = path["pierce_point"]
            lines.append(f"(SEQ {op['sequence_index']} | {op['contour_type'].upper()} | PART {op['layout_part_id']})")
            lines.append(f"G00 X{px:.3f} Y{py:.3f}")
            lines.append(laser_on)
            lines.append(pierce_cmd)
            for lx, ly in path["lead_in_path"][1:]:
                lines.append(f"G01 X{lx:.3f} Y{ly:.3f} F{feed_rate}")
            for cx, cy in path["cut_path"][1:]:
                lines.append(f"G01 X{cx:.3f} Y{cy:.3f}")
            for ox, oy in path["lead_out_path"][1:]:
                lines.append(f"G01 X{ox:.3f} Y{oy:.3f}")
            lines.append(laser_off)

        lines.extend(["G00 X0.000 Y0.000", "M30", "%"])
        return "\n".join(lines).encode("utf-8")


POSTPROCESSOR_REGISTRY: Dict[str, BasePostprocessor] = {
    "universal_json": UniversalIntermediatePostprocessor(),
    "reference_iso_6983": ReferenceISO6983Postprocessor(),
}
