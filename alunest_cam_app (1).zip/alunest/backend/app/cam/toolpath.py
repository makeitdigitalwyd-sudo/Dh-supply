from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from shapely import wkt as shapely_wkt
from shapely.geometry import LineString, Polygon

Pt = Tuple[float, float]


@dataclass
class ContourNode:
    node_id: int
    layout_part_id: int
    part_id: int
    sheet_index: int
    contour_type: str  # 'internal' | 'external'
    parent_part_key: Tuple[int, int]  # (sheet_index, layout_part_id)
    points: List[Pt]
    pierce_point: Pt
    lead_in_path: List[Pt]
    lead_out_path: List[Pt]
    cut_length_mm: float
    centroid: Pt


@dataclass
class ToolpathStep:
    sequence_index: int
    layout_part_id: int
    sheet_index: int
    contour_type: str
    rapid_from: Pt
    pierce_point: Pt
    lead_in_path: List[Pt]
    cut_path: List[Pt]
    lead_out_path: List[Pt]
    rapid_length_mm: float
    cut_length_mm: float


@dataclass
class ToolpathResult:
    total_cut_distance_mm: float
    total_rapid_distance_mm: float
    pierce_count: int
    internal_contour_count: int
    external_contour_count: int
    estimated_time_sec: float
    steps: List[ToolpathStep] = field(default_factory=list)


def _ring_length(pts: List[Pt]) -> float:
    return sum(math.hypot(pts[i + 1][0] - pts[i][0], pts[i + 1][1] - pts[i][1]) for i in range(len(pts) - 1))


def _compute_lead_in_out(
    pts: List[Pt],
    is_internal: bool,
    lead_in_mm: float,
    lead_out_mm: float,
) -> Tuple[Pt, List[Pt], List[Pt]]:
    """Computes pierce point, lead-in segment, and lead-out segment normal to the first edge."""
    if len(pts) < 2:
        p = pts[0] if pts else (0.0, 0.0)
        return p, [p], [p]
    p0, p1 = pts[0], pts[1]
    dx, dy = p1[0] - p0[0], p1[1] - p0[1]
    seg_len = math.hypot(dx, dy)
    if seg_len < 1e-6:
        return p0, [p0], [p0]

    # Left normal (-dy, dx). For CCW exterior, inward is left normal, outward is right normal.
    nx, ny = -dy / seg_len, dx / seg_len
    sign = 1.0 if is_internal else -1.0
    pierce = (round(p0[0] + sign * nx * lead_in_mm, 3), round(p0[1] + sign * ny * lead_in_mm, 3))
    lead_in = [pierce, (round(p0[0], 3), round(p0[1], 3))]
    lead_out_end = (round(p0[0] + sign * nx * lead_out_mm, 3), round(p0[1] + sign * ny * lead_out_mm, 3))
    lead_out = [(round(p0[0], 3), round(p0[1], 3)), lead_out_end]
    return pierce, lead_in, lead_out


def generate_optimized_toolpath(
    placed_parts: List[Dict[str, Any]],
    kerf_mm: float = 0.2,
    lead_in_mm: float = 3.0,
    lead_out_mm: float = 1.0,
    cutting_speed_mm_min: float = 3000.0,
    rapid_speed_mm_min: float = 20000.0,
    pierce_time_sec: float = 0.4,
    thermal_spacing_weight: float = 0.35,
) -> ToolpathResult:
    """
    Generates laser cutting toolpath with strict internal-before-external dependency,
    kerf compensation, lead-in/lead-out, and thermal-aware travel optimization.
    """
    nodes: List[ContourNode] = []
    node_id = 1

    for pp in placed_parts:
        geom = shapely_wkt.loads(pp["placed_wkt"])
        polys = list(geom.geoms) if hasattr(geom, "geoms") else [geom]
        s_idx = int(pp.get("sheet_index", 1))
        lp_id = int(pp["id"])
        p_id = int(pp["part_id"])
        pkey = (s_idx, lp_id)

        for poly in polys:
            if not isinstance(poly, Polygon):
                continue

            # 1. Internal holes (offset inward by kerf/2)
            for hole in poly.interiors:
                h_poly = Polygon(hole.coords)
                if kerf_mm > 0:
                    comp = h_poly.buffer(-kerf_mm / 2.0)
                    coords = list(comp.exterior.coords) if isinstance(comp, Polygon) and not comp.is_empty else list(hole.coords)
                else:
                    coords = list(hole.coords)
                pts = [(round(x, 3), round(y, 3)) for x, y in coords]
                pierce, lin, lout = _compute_lead_in_out(pts, True, lead_in_mm, lead_out_mm)
                c = h_poly.centroid
                nodes.append(ContourNode(
                    node_id=node_id,
                    layout_part_id=lp_id,
                    part_id=p_id,
                    sheet_index=s_idx,
                    contour_type="internal",
                    parent_part_key=pkey,
                    points=pts,
                    pierce_point=pierce,
                    lead_in_path=lin,
                    lead_out_path=lout,
                    cut_length_mm=round(_ring_length(pts) + lead_in_mm + lead_out_mm, 3),
                    centroid=(c.x, c.y),
                ))
                node_id += 1

            # 2. External contour (offset outward by kerf/2)
            if kerf_mm > 0:
                comp_ext = poly.buffer(kerf_mm / 2.0, join_style=2)
                ext_coords = list(comp_ext.exterior.coords) if isinstance(comp_ext, Polygon) and not comp_ext.is_empty else list(poly.exterior.coords)
            else:
                ext_coords = list(poly.exterior.coords)
            pts = [(round(x, 3), round(y, 3)) for x, y in ext_coords]
            pierce, lin, lout = _compute_lead_in_out(pts, False, lead_in_mm, lead_out_mm)
            c = poly.centroid
            nodes.append(ContourNode(
                node_id=node_id,
                layout_part_id=lp_id,
                part_id=p_id,
                sheet_index=s_idx,
                contour_type="external",
                parent_part_key=pkey,
                points=pts,
                pierce_point=pierce,
                lead_in_path=lin,
                lead_out_path=lout,
                cut_length_mm=round(_ring_length(pts) + lead_in_mm + lead_out_mm, 3),
                centroid=(c.x, c.y),
            ))
            node_id += 1

    # Track remaining internal contours per part
    remaining_internals: Dict[Tuple[int, int], int] = {}
    for nd in nodes:
        if nd.contour_type == "internal":
            remaining_internals[nd.parent_part_key] = remaining_internals.get(nd.parent_part_key, 0) + 1

    unvisited = list(nodes)
    steps: List[ToolpathStep] = []
    cur_pos: Pt = (0.0, 0.0)
    last_cut_centroid: Optional[Pt] = None
    total_cut = 0.0
    total_rapid = 0.0
    seq = 1

    while unvisited:
        eligible = [
            nd for nd in unvisited
            if nd.contour_type == "internal" or remaining_internals.get(nd.parent_part_key, 0) == 0
        ]
        # Prefer internal contours first on the same sheet, then nearest travel + thermal dispersion
        best_nd: Optional[ContourNode] = None
        best_cost: Optional[float] = None

        for nd in eligible:
            rapid_d = math.hypot(nd.pierce_point[0] - cur_pos[0], nd.pierce_point[1] - cur_pos[1])
            # Thermal penalty: avoid cutting right next to the immediately previous contour if alternatives exist
            thermal_pen = 0.0
            if last_cut_centroid is not None and thermal_spacing_weight > 0:
                cdist = math.hypot(nd.centroid[0] - last_cut_centroid[0], nd.centroid[1] - last_cut_centroid[1])
                if cdist < 80.0:
                    thermal_pen = (80.0 - cdist) * thermal_spacing_weight
            # Sheet grouping + internal priority
            type_bias = 0.0 if nd.contour_type == "internal" else 25.0
            cost = (nd.sheet_index * 10000.0) + rapid_d + thermal_pen + type_bias
            if best_cost is None or cost < best_cost:
                best_cost = cost
                best_nd = nd

        assert best_nd is not None
        unvisited.remove(best_nd)
        if best_nd.contour_type == "internal":
            remaining_internals[best_nd.parent_part_key] -= 1

        rapid_d = round(math.hypot(best_nd.pierce_point[0] - cur_pos[0], best_nd.pierce_point[1] - cur_pos[1]), 3)
        steps.append(ToolpathStep(
            sequence_index=seq,
            layout_part_id=best_nd.layout_part_id,
            sheet_index=best_nd.sheet_index,
            contour_type=best_nd.contour_type,
            rapid_from=cur_pos,
            pierce_point=best_nd.pierce_point,
            lead_in_path=best_nd.lead_in_path,
            cut_path=best_nd.points,
            lead_out_path=best_nd.lead_out_path,
            rapid_length_mm=rapid_d,
            cut_length_mm=best_nd.cut_length_mm,
        ))
        total_cut += best_nd.cut_length_mm
        total_rapid += rapid_d
        cur_pos = best_nd.lead_out_path[-1]
        last_cut_centroid = best_nd.centroid
        seq += 1

    cut_sec = (total_cut / cutting_speed_mm_min) * 60.0 if cutting_speed_mm_min > 0 else 0.0
    rapid_sec = (total_rapid / rapid_speed_mm_min) * 60.0 if rapid_speed_mm_min > 0 else 0.0
    pierce_sec = len(steps) * pierce_time_sec

    return ToolpathResult(
        total_cut_distance_mm=round(total_cut, 2),
        total_rapid_distance_mm=round(total_rapid, 2),
        pierce_count=len(steps),
        internal_contour_count=sum(1 for s in steps if s.contour_type == "internal"),
        external_contour_count=sum(1 for s in steps if s.contour_type == "external"),
        estimated_time_sec=round(cut_sec + rapid_sec + pierce_sec, 2),
        steps=steps,
    )
