from __future__ import annotations

from typing import Any, Dict, List

from shapely import wkt as shapely_wkt
from shapely.geometry import Polygon


def _lwpolyline_dxf(coords: List[tuple], layer: str, closed: bool = True) -> str:
    pts = list(coords)
    if closed and len(pts) > 1 and pts[0] == pts[-1]:
        pts = pts[:-1]
    lines = [
        "0", "LWPOLYLINE",
        "8", layer,
        "90", str(len(pts)),
        "70", "1" if closed else "0",
    ]
    for x, y in pts:
        lines.extend(["10", f"{x:.4f}", "20", f"{y:.4f}"])
    return "\n".join(lines) + "\n"


def _text_dxf(x: float, y: float, text: str, layer: str = "PART_LABELS", height: float = 8.0) -> str:
    return "\n".join([
        "0", "TEXT",
        "8", layer,
        "10", f"{x:.4f}",
        "20", f"{y:.4f}",
        "40", f"{height:.2f}",
        "1", text,
    ]) + "\n"


def export_sheet_to_dxf_bytes(
    sheet_width_mm: float,
    sheet_height_mm: float,
    placed_parts: List[Dict[str, Any]],
    include_labels: bool = True,
) -> bytes:
    """Generates a valid ASCII DXF (AC1015, mm units) with real geometric entities and distinct layers."""
    entities: List[str] = []

    # Sheet boundary layer
    entities.append(_lwpolyline_dxf(
        [(0.0, 0.0), (sheet_width_mm, 0.0), (sheet_width_mm, sheet_height_mm), (0.0, sheet_height_mm)],
        layer="SHEET_BOUNDARY",
        closed=True,
    ))

    for pp in placed_parts:
        geom = shapely_wkt.loads(pp["placed_wkt"])
        polys = list(geom.geoms) if hasattr(geom, "geoms") else [geom]
        for poly in polys:
            if not isinstance(poly, Polygon):
                continue
            entities.append(_lwpolyline_dxf(list(poly.exterior.coords), layer="CUT_EXTERNAL", closed=True))
            for hole in poly.interiors:
                entities.append(_lwpolyline_dxf(list(hole.coords), layer="CUT_INTERNAL", closed=True))
        if include_labels:
            c = geom.centroid
            label = f"{pp.get('part_name', 'PART')} #{pp.get('instance_index', 1)}"
            entities.append(_text_dxf(c.x, c.y, label, layer="PART_LABELS"))

    dxf_str = (
        "0\nSECTION\n2\nHEADER\n"
        "9\n$ACADVER\n1\nAC1015\n"
        "9\n$INSUNITS\n70\n4\n"
        "0\nENDSEC\n"
        "0\nSECTION\n2\nENTITIES\n"
        + "".join(entities)
        + "0\nENDSEC\n0\nEOF\n"
    )
    return dxf_str.encode("utf-8")
