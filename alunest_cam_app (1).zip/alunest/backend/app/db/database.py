import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

from app.config import DB_PATH

SQLITE_SCHEMA = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS roles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    description TEXT,
    permissions_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    full_name TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    role_id INTEGER NOT NULL REFERENCES roles(id),
    is_active INTEGER NOT NULL DEFAULT 1,
    reset_token TEXT,
    reset_token_expires_at TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

CREATE TABLE IF NOT EXISTS customers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    contact_email TEXT,
    contact_phone TEXT,
    company_code TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS projects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER REFERENCES customers(id),
    customer_name TEXT NOT NULL,
    reference_code TEXT NOT NULL,
    name TEXT NOT NULL,
    description TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'draft',
    created_by INTEGER REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS dxf_files (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    original_filename TEXT NOT NULL,
    storage_key TEXT NOT NULL,
    file_size_bytes INTEGER NOT NULL,
    sha256_hash TEXT NOT NULL,
    dxf_version TEXT,
    units TEXT NOT NULL DEFAULT 'mm',
    unit_scale_to_mm REAL NOT NULL DEFAULT 1.0,
    validation_status TEXT NOT NULL DEFAULT 'pending',
    validation_report_json TEXT NOT NULL DEFAULT '{}',
    geometry_confirmed INTEGER NOT NULL DEFAULT 0,
    disconnected_mode TEXT NOT NULL DEFAULT 'ask',
    uploaded_by INTEGER REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_dxf_files_project ON dxf_files(project_id);

CREATE TABLE IF NOT EXISTS parts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    dxf_file_id INTEGER NOT NULL REFERENCES dxf_files(id) ON DELETE CASCADE,
    part_name TEXT NOT NULL,
    original_filename TEXT NOT NULL,
    width_mm REAL NOT NULL,
    height_mm REAL NOT NULL,
    area_mm2 REAL NOT NULL,
    perimeter_mm REAL NOT NULL,
    internal_hole_count INTEGER NOT NULL DEFAULT 0,
    quantity INTEGER NOT NULL DEFAULT 1,
    allowed_rotations_json TEXT NOT NULL DEFAULT '[0, 90, 180, 270]',
    material_type TEXT NOT NULL DEFAULT 'Aluminium',
    aluminium_grade TEXT NOT NULL DEFAULT '5052-H32',
    thickness_mm REAL NOT NULL DEFAULT 2.0,
    validation_status TEXT NOT NULL DEFAULT 'valid',
    geometry_wkt TEXT NOT NULL,
    svg_preview TEXT NOT NULL,
    is_library_part INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_parts_project ON parts(project_id);

CREATE TABLE IF NOT EXISTS part_instances (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    part_id INTEGER NOT NULL REFERENCES parts(id) ON DELETE CASCADE,
    instance_index INTEGER NOT NULL,
    label TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS materials (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    grade TEXT NOT NULL,
    density_kg_m3 REAL NOT NULL DEFAULT 2700.0,
    cost_per_kg REAL NOT NULL DEFAULT 0.0
);

CREATE TABLE IF NOT EXISTS material_profiles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    material_id INTEGER REFERENCES materials(id),
    thickness_mm REAL NOT NULL,
    default_kerf_mm REAL NOT NULL DEFAULT 0.2,
    default_edge_margin_mm REAL NOT NULL DEFAULT 10.0,
    default_part_gap_mm REAL NOT NULL DEFAULT 3.0,
    grain_direction TEXT DEFAULT 'none'
);

CREATE TABLE IF NOT EXISTS sheet_inventory (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    material_id INTEGER REFERENCES materials(id),
    grade TEXT NOT NULL,
    thickness_mm REAL NOT NULL,
    width_mm REAL NOT NULL,
    height_mm REAL NOT NULL,
    quantity_available INTEGER NOT NULL DEFAULT 0,
    quantity_consumed INTEGER NOT NULL DEFAULT 0,
    cost_per_sheet REAL NOT NULL DEFAULT 0.0,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS nesting_jobs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    material_profile_id INTEGER REFERENCES material_profiles(id),
    sheet_width_mm REAL NOT NULL,
    sheet_height_mm REAL NOT NULL,
    edge_margin_mm REAL NOT NULL DEFAULT 10.0,
    part_gap_mm REAL NOT NULL DEFAULT 3.0,
    kerf_mm REAL NOT NULL DEFAULT 0.2,
    objective TEXT NOT NULL DEFAULT 'max_utilization',
    status TEXT NOT NULL DEFAULT 'pending',
    utilization_pct REAL DEFAULT 0.0,
    wastage_pct REAL DEFAULT 100.0,
    sheet_count INTEGER DEFAULT 0,
    is_approved INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS nesting_layouts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nesting_job_id INTEGER NOT NULL REFERENCES nesting_jobs(id) ON DELETE CASCADE,
    candidate_index INTEGER NOT NULL DEFAULT 1,
    sheet_index INTEGER NOT NULL DEFAULT 1,
    sheet_width_mm REAL NOT NULL,
    sheet_height_mm REAL NOT NULL,
    utilization_pct REAL NOT NULL DEFAULT 0.0,
    used_area_mm2 REAL NOT NULL DEFAULT 0.0,
    is_selected INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS layout_parts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nesting_layout_id INTEGER NOT NULL REFERENCES nesting_layouts(id) ON DELETE CASCADE,
    part_id INTEGER NOT NULL REFERENCES parts(id),
    instance_index INTEGER NOT NULL,
    pos_x_mm REAL NOT NULL,
    pos_y_mm REAL NOT NULL,
    rotation_deg REAL NOT NULL DEFAULT 0.0,
    is_locked INTEGER NOT NULL DEFAULT 0,
    placed_wkt TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS machine_profiles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    manufacturer TEXT NOT NULL,
    model TEXT NOT NULL,
    controller TEXT NOT NULL,
    file_extension TEXT NOT NULL DEFAULT '.nc',
    units TEXT NOT NULL DEFAULT 'mm',
    config_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS postprocessors (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    controller TEXT NOT NULL,
    version TEXT NOT NULL DEFAULT '1.0',
    is_verified INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS toolpaths (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nesting_job_id INTEGER NOT NULL REFERENCES nesting_jobs(id) ON DELETE CASCADE,
    machine_profile_id INTEGER REFERENCES machine_profiles(id),
    total_cut_distance_mm REAL NOT NULL DEFAULT 0.0,
    total_rapid_distance_mm REAL NOT NULL DEFAULT 0.0,
    pierce_count INTEGER NOT NULL DEFAULT 0,
    estimated_time_sec REAL NOT NULL DEFAULT 0.0,
    simulation_verified INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS cutting_operations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    toolpath_id INTEGER NOT NULL REFERENCES toolpaths(id) ON DELETE CASCADE,
    sequence_index INTEGER NOT NULL,
    layout_part_id INTEGER REFERENCES layout_parts(id),
    contour_type TEXT NOT NULL,
    pierce_x_mm REAL NOT NULL,
    pierce_y_mm REAL NOT NULL,
    cut_length_mm REAL NOT NULL,
    path_json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS export_files (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    nesting_job_id INTEGER REFERENCES nesting_jobs(id),
    export_type TEXT NOT NULL,
    storage_key TEXT NOT NULL,
    version_number INTEGER NOT NULL DEFAULT 1,
    approved_by INTEGER REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS remnants (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    remnant_code TEXT UNIQUE NOT NULL,
    source_layout_id INTEGER REFERENCES nesting_layouts(id),
    grade TEXT NOT NULL,
    thickness_mm REAL NOT NULL,
    width_mm REAL NOT NULL,
    height_mm REAL NOT NULL,
    area_mm2 REAL NOT NULL,
    geometry_wkt TEXT NOT NULL,
    is_available INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS job_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    user_id INTEGER REFERENCES users(id),
    action TEXT NOT NULL,
    details_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
"""

ROLE_SEEDS = [
    ("Administrator", "Full system administration, user/role management, machine profiles, all workflows", {
        "manage_users": True, "manage_projects": True, "upload_dxf": True,
        "edit_parts": True, "run_nesting": True, "approve_layout": True,
        "generate_toolpath": True, "export_nc": True, "manage_inventory": True,
    }),
    ("Production Manager", "Project management, nesting approval, inventory, cost & production reports", {
        "manage_users": False, "manage_projects": True, "upload_dxf": True,
        "edit_parts": True, "run_nesting": True, "approve_layout": True,
        "generate_toolpath": True, "export_nc": True, "manage_inventory": True,
    }),
    ("CAD Designer", "Upload/validate DXF files, manage part library, run nesting previews", {
        "manage_users": False, "manage_projects": True, "upload_dxf": True,
        "edit_parts": True, "run_nesting": True, "approve_layout": False,
        "generate_toolpath": False, "export_nc": False, "manage_inventory": False,
    }),
    ("Machine Operator", "Simulate cutting, approve machine execution, export validated NC/DXF, log remnants", {
        "manage_users": False, "manage_projects": False, "upload_dxf": False,
        "edit_parts": False, "run_nesting": False, "approve_layout": True,
        "generate_toolpath": True, "export_nc": True, "manage_inventory": True,
    }),
]


def init_db(db_path: Path | None = None) -> None:
    target = db_path or DB_PATH
    target.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(target))
    try:
        conn.executescript(SQLITE_SCHEMA)
        for role_name, desc, perms in ROLE_SEEDS:
            conn.execute(
                "INSERT OR IGNORE INTO roles (name, description, permissions_json) VALUES (?, ?, ?)",
                (role_name, desc, json.dumps(perms)),
            )
        conn.commit()
    finally:
        conn.close()


@contextmanager
def get_db(db_path: Path | None = None) -> Iterator[sqlite3.Connection]:
    target = db_path or DB_PATH
    conn = sqlite3.connect(str(target), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    try:
        yield conn
    finally:
        conn.close()
