from __future__ import annotations

from typing import Any, Dict, List

from fpdf import FPDF
from shapely import wkt as shapely_wkt
from shapely.geometry import Polygon


def generate_production_pdf(
    project: Dict[str, Any],
    job: Dict[str, Any],
    sheets: List[Dict[str, Any]],
    parts_summary: List[Dict[str, Any]],
    toolpath_meta: Dict[str, Any] | None,
) -> bytes:
    pdf = FPDF(orientation="P", unit="mm", format="A4")
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()

    # Header
    pdf.set_font("Helvetica", "B", 16)
    pdf.cell(0, 10, "ALUNEST CAM - LASER CUTTING PRODUCTION REPORT", ln=True)
    pdf.set_font("Helvetica", "", 10)
    pdf.cell(0, 6, f"Project: {project['name']} ({project['reference_code']}) | Customer: {project['customer_name']}", ln=True)
    pdf.cell(0, 6, f"Job ID: #{job['id']} | Sheet: {job['sheet_width_mm']} x {job['sheet_height_mm']} mm | Sheets Required: {job['sheet_count']}", ln=True)
    pdf.cell(0, 6, f"Edge Margin: {job['edge_margin_mm']} mm | Part Gap: {job['part_gap_mm']} mm | Kerf: {job['kerf_mm']} mm", ln=True)
    pdf.ln(4)

    # Utilization KPIs
    total_sheet_area = job["sheet_width_mm"] * job["sheet_height_mm"] * max(job["sheet_count"], 1)
    used_area = sum(s["used_area_mm2"] for s in sheets)
    wasted_area = max(total_sheet_area - used_area, 0.0)

    pdf.set_font("Helvetica", "B", 12)
    pdf.cell(0, 8, "1. Material Utilization Summary", ln=True)
    pdf.set_font("Helvetica", "", 10)
    pdf.cell(0, 6, f"Total Sheet Area: {total_sheet_area:,.1f} mm2 | Used Part Area: {used_area:,.1f} mm2 | Wasted Area: {wasted_area:,.1f} mm2", ln=True)
    pdf.cell(0, 6, f"Geometric Utilization: {job['utilization_pct']:.2f}% | Wastage: {job['wastage_pct']:.2f}%", ln=True)
    if toolpath_meta:
        pdf.cell(
            0, 6,
            f"Cutting Distance: {toolpath_meta['total_cut_distance_mm']:,.1f} mm | "
            f"Rapid Distance: {toolpath_meta['total_rapid_distance_mm']:,.1f} mm | "
            f"Pierces: {toolpath_meta['pierce_count']} | Est. Time: {toolpath_meta['estimated_time_sec']:.1f} s",
            ln=True,
        )
    pdf.ln(4)

    # Component Table
    pdf.set_font("Helvetica", "B", 12)
    pdf.cell(0, 8, "2. Component Schedule", ln=True)
    pdf.set_font("Helvetica", "B", 9)
    pdf.cell(55, 7, "Part Name", border=1)
    pdf.cell(35, 7, "Dimensions (mm)", border=1)
    pdf.cell(20, 7, "Qty", border=1)
    pdf.cell(30, 7, "Area (mm2)", border=1)
    pdf.cell(25, 7, "Holes", border=1)
    pdf.cell(25, 7, "Material", border=1, ln=True)

    pdf.set_font("Helvetica", "", 9)
    for pt in parts_summary:
        pdf.cell(55, 6, str(pt["part_name"])[:28], border=1)
        pdf.cell(35, 6, f"{pt['width_mm']:.1f} x {pt['height_mm']:.1f}", border=1)
        pdf.cell(20, 6, str(pt["quantity"]), border=1)
        pdf.cell(30, 6, f"{pt['area_mm2']:,.1f}", border=1)
        pdf.cell(25, 6, str(pt["internal_hole_count"]), border=1)
        pdf.cell(25, 6, f"{pt['thickness_mm']}mm", border=1, ln=True)

    # Sheet Layout Drawings
    for s in sheets:
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 12)
        pdf.cell(0, 8, f"Sheet #{s['sheet_index']} Layout - Utilization: {s['utilization_pct']:.2f}%", ln=True)

        draw_w = 180.0
        scale = draw_w / max(s["sheet_width_mm"], 1.0)
        draw_h = s["sheet_height_mm"] * scale
        if draw_h > 220.0:
            scale = 220.0 / max(s["sheet_height_mm"], 1.0)
            draw_w = s["sheet_width_mm"] * scale
            draw_h = 220.0

        ox, oy = 15.0, 28.0
        pdf.set_draw_color(30, 41, 59)
        pdf.rect(ox, oy, draw_w, draw_h)

        pdf.set_draw_color(14, 165, 233)
        for pp in s["placed_parts"]:
            geom = shapely_wkt.loads(pp["placed_wkt"])
            polys = list(geom.geoms) if hasattr(geom, "geoms") else [geom]
            for poly in polys:
                if not isinstance(poly, Polygon):
                    continue
                coords = list(poly.exterior.coords)
                for k in range(len(coords) - 1):
                    x1 = ox + coords[k][0] * scale
                    y1 = oy + draw_h - coords[k][1] * scale
                    x2 = ox + coords[k + 1][0] * scale
                    y2 = oy + draw_h - coords[k + 1][1] * scale
                    pdf.line(x1, y1, x2, y2)

    return bytes(pdf.output())
