from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from shapely import wkt as shapely_wkt
from shapely.affinity import rotate, translate
from shapely.geometry import MultiPolygon, Polygon, box
from shapely.ops import unary_union


@dataclass
class NestingPartInput:
    part_id: int
    part_name: str
    quantity: int
    allowed_rotations: List[int]
    geometry: Polygon | MultiPolygon
    priority: int = 0


@dataclass
class LockedPlacement:
    part_id: int
    instance_index: int
    sheet_index: int
    pos_x_mm: float
    pos_y_mm: float
    rotation_deg: float
    geometry: Polygon | MultiPolygon


@dataclass
class PlacedInstance:
    part_id: int
    part_name: str
    instance_index: int
    sheet_index: int
    pos_x_mm: float
    pos_y_mm: float
    rotation_deg: float
    is_locked: bool
    geometry: Polygon | MultiPolygon
    area_mm2: float


@dataclass
class SheetResult:
    sheet_index: int
    width_mm: float
    height_mm: float
    used_area_mm2: float
    utilization_pct: float
    placed_parts: List[PlacedInstance] = field(default_factory=list)
    remnant_candidates: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class CandidateLayout:
    candidate_index: int
    strategy_name: str
    objective: str
    sheet_count: int
    total_sheet_area_mm2: float
    total_used_area_mm2: float
    utilization_pct: float
    wastage_pct: float
    estimated_travel_mm: float
    sheets: List[SheetResult]
    unplaced_count: int = 0


def _rotate_and_normalize(geom: Polygon | MultiPolygon, angle_deg: float) -> Polygon | MultiPolygon:
    rotated = rotate(geom, angle_deg, origin="centroid", use_radians=False) if angle_deg != 0 else geom
    minx, miny, _, _ = rotated.bounds
    return translate(rotated, xoff=-minx, yoff=-miny)


def _find_best_position_on_sheet(
    poly: Polygon | MultiPolygon,
    placed_geoms: List[Polygon | MultiPolygon],
    placed_buffered: List[Polygon | MultiPolygon],
    usable_box: Polygon,
    min_x: float,
    min_y: float,
    max_x: float,
    max_y: float,
    clearance: float,
    objective: str,
) -> Optional[Tuple[float, float, Polygon | MultiPolygon]]:
    pw = poly.bounds[2] - poly.bounds[0]
    ph = poly.bounds[3] - poly.bounds[1]
    if min_x + pw > max_x + 1e-6 or min_y + ph > max_y + 1e-6:
        return None

    # Candidate X and Y coordinates from sheet origin + NFP-inspired contact edges of placed parts
    cand_xs = {min_x}
    cand_ys = {min_y}
    for pg in placed_geoms:
        bx1, by1, bx2, by2 = pg.bounds
        cand_xs.add(bx2 + clearance)
        cand_ys.add(by2 + clearance)
        cand_xs.add(bx1)
        cand_ys.add(by1)

    sorted_xs = sorted(x for x in cand_xs if min_x - 1e-6 <= x <= max_x - pw + 1e-6)
    sorted_ys = sorted(y for y in cand_ys if min_y - 1e-6 <= y <= max_y - ph + 1e-6)

    # Fine-grain grid fallback if sparse
    if len(sorted_xs) < 6:
        step_x = max(10.0, (max_x - min_x - pw) / 12.0)
        x_cur = min_x
        while x_cur <= max_x - pw + 1e-6:
            sorted_xs.append(x_cur)
            x_cur += step_x
        sorted_xs = sorted(set(round(v, 3) for v in sorted_xs))
    if len(sorted_ys) < 6:
        step_y = max(10.0, (max_y - min_y - ph) / 12.0)
        y_cur = min_y
        while y_cur <= max_y - ph + 1e-6:
            sorted_ys.append(y_cur)
            y_cur += step_y
        sorted_ys = sorted(set(round(v, 3) for v in sorted_ys))

    best_score: Optional[float] = None
    best_placement: Optional[Tuple[float, float, Polygon | MultiPolygon]] = None

    last_c = placed_geoms[-1].centroid if placed_geoms else None

    for y in sorted_ys:
        for x in sorted_xs:
            cand = translate(poly, xoff=x, yoff=y)
            if not usable_box.buffer(1e-5).contains(cand):
                continue
            collision = False
            for pb in placed_buffered:
                if cand.intersects(pb):
                    collision = True
                    break
            if collision:
                continue

            # Slide left & down locally (NFP-like compaction) for tighter true-shape packing
            cur_x, cur_y = x, y
            for step in (10.0, 2.0, 0.5):
                while cur_x - step >= min_x - 1e-6:
                    test_c = translate(poly, xoff=cur_x - step, yoff=cur_y)
                    if usable_box.buffer(1e-5).contains(test_c) and not any(test_c.intersects(pb) for pb in placed_buffered):
                        cur_x -= step
                    else:
                        break
                while cur_y - step >= min_y - 1e-6:
                    test_c = translate(poly, xoff=cur_x, yoff=cur_y - step)
                    if usable_box.buffer(1e-5).contains(test_c) and not any(test_c.intersects(pb) for pb in placed_buffered):
                        cur_y -= step
                    else:
                        break

            final_cand = translate(poly, xoff=cur_x, yoff=cur_y)
            if objective == "min_travel" and last_c is not None:
                fc = final_cand.centroid
                score = math.hypot(fc.x - last_c.x, fc.y - last_c.y)
            elif objective == "balanced":
                score = cur_y * 1.5 + cur_x * 1.0
            else:
                # Bottom-left fill minimizes bounding extent
                score = (cur_y + ph) * 2.0 + (cur_x + pw)

            if best_score is None or score < best_score:
                best_score = score
                best_placement = (cur_x, cur_y, final_cand)
                # Early exit if we found an origin-flush placement
                if cur_x <= min_x + 1.0 and cur_y <= min_y + 1.0 and objective != "min_travel":
                    return best_placement

    return best_placement


def _detect_remnants(
    sheet_w: float,
    sheet_h: float,
    margin: float,
    placed_geoms: List[Polygon | MultiPolygon],
    min_remnant_dim: float = 150.0,
) -> List[Dict[str, Any]]:
    usable = box(margin, margin, sheet_w - margin, sheet_h - margin)
    if not placed_geoms:
        return [{
            "width_mm": round(sheet_w - 2 * margin, 2),
            "height_mm": round(sheet_h - 2 * margin, 2),
            "area_mm2": round(usable.area, 2),
            "geometry_wkt": usable.wkt,
        }]

    union_placed = unary_union([g.buffer(2.0) for g in placed_geoms])
    max_x = max(g.bounds[2] for g in placed_geoms)
    max_y = max(g.bounds[3] for g in placed_geoms)

    remnants: List[Dict[str, Any]] = []
    # Right guillotine strip
    right_w = (sheet_w - margin) - max_x
    if right_w >= min_remnant_dim and (sheet_h - 2 * margin) >= min_remnant_dim:
        r_box = box(max_x, margin, sheet_w - margin, sheet_h - margin)
        if not r_box.intersects(union_placed):
            remnants.append({
                "width_mm": round(right_w, 2),
                "height_mm": round(sheet_h - 2 * margin, 2),
                "area_mm2": round(r_box.area, 2),
                "geometry_wkt": r_box.wkt,
            })

    # Top guillotine strip (above placed parts, left of right strip)
    top_h = (sheet_h - margin) - max_y
    top_w = max_x - margin
    if top_h >= min_remnant_dim and top_w >= min_remnant_dim:
        t_box = box(margin, max_y, max_x, sheet_h - margin)
        if not t_box.intersects(union_placed):
            remnants.append({
                "width_mm": round(top_w, 2),
                "height_mm": round(top_h, 2),
                "area_mm2": round(t_box.area, 2),
                "geometry_wkt": t_box.wkt,
            })
    return remnants


def _run_single_candidate(
    candidate_index: int,
    strategy_name: str,
    ordered_instances: List[Tuple[NestingPartInput, int]],
    sheet_w: float,
    sheet_h: float,
    margin: float,
    part_gap: float,
    kerf: float,
    objective: str,
    locked_placements: List[LockedPlacement],
) -> CandidateLayout:
    clearance = part_gap + kerf
    usable_box = box(margin, margin, sheet_w - margin, sheet_h - margin)
    min_x, min_y, max_x, max_y = margin, margin, sheet_w - margin, sheet_h - margin

    sheets_placed: Dict[int, List[PlacedInstance]] = {}
    sheets_geoms: Dict[int, List[Polygon | MultiPolygon]] = {}
    sheets_buffered: Dict[int, List[Polygon | MultiPolygon]] = {}

    locked_keys = set()
    for lp in locked_placements:
        s_idx = lp.sheet_index
        sheets_placed.setdefault(s_idx, []).append(PlacedInstance(
            part_id=lp.part_id,
            part_name=f"Part-{lp.part_id}",
            instance_index=lp.instance_index,
            sheet_index=s_idx,
            pos_x_mm=lp.pos_x_mm,
            pos_y_mm=lp.pos_y_mm,
            rotation_deg=lp.rotation_deg,
            is_locked=True,
            geometry=lp.geometry,
            area_mm2=lp.geometry.area,
        ))
        sheets_geoms.setdefault(s_idx, []).append(lp.geometry)
        sheets_buffered.setdefault(s_idx, []).append(lp.geometry.buffer(max(clearance - 1e-4, 0.0)))
        locked_keys.add((lp.part_id, lp.instance_index))

    if not sheets_placed:
        sheets_placed[1] = []
        sheets_geoms[1] = []
        sheets_buffered[1] = []

    unplaced_count = 0
    for part, inst_idx in ordered_instances:
        if (part.part_id, inst_idx) in locked_keys:
            continue

        placed_ok = False
        rotations = part.allowed_rotations or [0]
        # Try existing sheets first, then open a new sheet
        sheet_indices = sorted(sheets_placed.keys()) + [max(sheets_placed.keys()) + 1]

        for s_idx in sheet_indices:
            if s_idx not in sheets_placed:
                sheets_placed[s_idx] = []
                sheets_geoms[s_idx] = []
                sheets_buffered[s_idx] = []

            best_rot_choice = None
            best_rot_metric = None

            for rot in rotations:
                rot_poly = _rotate_and_normalize(part.geometry, rot)
                res = _find_best_position_on_sheet(
                    rot_poly,
                    sheets_geoms[s_idx],
                    sheets_buffered[s_idx],
                    usable_box,
                    min_x, min_y, max_x, max_y,
                    clearance,
                    objective,
                )
                if res is not None:
                    px, py, placed_g = res
                    metric = (py + (placed_g.bounds[3] - placed_g.bounds[1])) * 1.5 + px
                    if best_rot_metric is None or metric < best_rot_metric:
                        best_rot_metric = metric
                        best_rot_choice = (px, py, rot, placed_g)

            if best_rot_choice is not None:
                px, py, rot, placed_g = best_rot_choice
                sheets_placed[s_idx].append(PlacedInstance(
                    part_id=part.part_id,
                    part_name=part.part_name,
                    instance_index=inst_idx,
                    sheet_index=s_idx,
                    pos_x_mm=round(px, 3),
                    pos_y_mm=round(py, 3),
                    rotation_deg=float(rot),
                    is_locked=False,
                    geometry=placed_g,
                    area_mm2=round(placed_g.area, 3),
                ))
                sheets_geoms[s_idx].append(placed_g)
                sheets_buffered[s_idx].append(placed_g.buffer(max(clearance - 1e-4, 0.0)))
                placed_ok = True
                break

        if not placed_ok:
            unplaced_count += 1

    # Remove trailing empty sheet if unused
    active_indices = sorted(k for k, v in sheets_placed.items() if len(v) > 0 or k == 1)
    sheet_results: List[SheetResult] = []
    sheet_area = sheet_w * sheet_h
    total_used = 0.0
    total_travel = 0.0

    for idx_out, s_idx in enumerate(active_indices, start=1):
        plist = sheets_placed[s_idx]
        for item in plist:
            item.sheet_index = idx_out
        used = sum(p.area_mm2 for p in plist)
        total_used += used
        util = round((used / sheet_area) * 100.0, 2) if sheet_area > 0 else 0.0

        # Estimate centroid travel
        for k in range(1, len(plist)):
            c1 = plist[k - 1].geometry.centroid
            c2 = plist[k].geometry.centroid
            total_travel += math.hypot(c2.x - c1.x, c2.y - c1.y)

        rems = _detect_remnants(sheet_w, sheet_h, margin, sheets_geoms[s_idx])
        sheet_results.append(SheetResult(
            sheet_index=idx_out,
            width_mm=sheet_w,
            height_mm=sheet_h,
            used_area_mm2=round(used, 2),
            utilization_pct=util,
            placed_parts=plist,
            remnant_candidates=rems,
        ))

    total_sheet_area = sheet_area * len(sheet_results)
    overall_util = round((total_used / total_sheet_area) * 100.0, 2) if total_sheet_area > 0 else 0.0
    return CandidateLayout(
        candidate_index=candidate_index,
        strategy_name=strategy_name,
        objective=objective,
        sheet_count=len(sheet_results),
        total_sheet_area_mm2=round(total_sheet_area, 2),
        total_used_area_mm2=round(total_used, 2),
        utilization_pct=overall_util,
        wastage_pct=round(100.0 - overall_util, 2),
        estimated_travel_mm=round(total_travel, 2),
        sheets=sheet_results,
        unplaced_count=unplaced_count,
    )


def run_polygon_nesting(
    parts: List[NestingPartInput],
    sheet_width_mm: float,
    sheet_height_mm: float,
    edge_margin_mm: float = 10.0,
    part_gap_mm: float = 3.0,
    kerf_mm: float = 0.2,
    objective: str = "max_utilization",
    locked_placements: Optional[List[LockedPlacement]] = None,
) -> List[CandidateLayout]:
    """
    True-shape Shapely/GEOS polygon nesting engine generating multiple heuristic candidate layouts.
    Note: Reports heuristic optimized candidates (not claimed mathematically optimal).
    """
    locked_placements = locked_placements or []
    base_instances: List[Tuple[NestingPartInput, int]] = []
    for p in parts:
        for idx in range(1, p.quantity + 1):
            base_instances.append((p, idx))

    # Strategy 1: Area descending (classic large-first)
    strat1 = sorted(base_instances, key=lambda x: (-x[0].priority, -x[0].geometry.area))
    # Strategy 2: Max bounding dimension descending
    strat2 = sorted(base_instances, key=lambda x: (-x[0].priority, -max(x[0].geometry.bounds[2] - x[0].geometry.bounds[0], x[0].geometry.bounds[3] - x[0].geometry.bounds[1])))
    # Strategy 3: Perimeter descending + randomized SA-style swap
    strat3 = sorted(base_instances, key=lambda x: (-x[0].priority, -x[0].geometry.length))
    rng = random.Random(42)
    if len(strat3) > 3:
        for _ in range(min(6, len(strat3))):
            a, b = rng.sample(range(len(strat3)), 2)
            if strat3[a][0].priority == strat3[b][0].priority:
                strat3[a], strat3[b] = strat3[b], strat3[a]

    strategies = [
        (1, "Area-Descending NFP-BLF", strat1),
        (2, "Max-Span NFP-BLF", strat2),
        (3, "SA-Perturbed Perimeter", strat3),
    ]

    candidates = [
        _run_single_candidate(
            idx, name, inst_list,
            sheet_width_mm, sheet_height_mm,
            edge_margin_mm, part_gap_mm, kerf_mm,
            objective, locked_placements,
        )
        for idx, name, inst_list in strategies
    ]

    # Rank candidates according to selected objective
    if objective == "min_sheets":
        candidates.sort(key=lambda c: (c.unplaced_count, c.sheet_count, -c.utilization_pct))
    elif objective == "min_travel":
        candidates.sort(key=lambda c: (c.unplaced_count, c.estimated_travel_mm, -c.utilization_pct))
    elif objective == "balanced":
        candidates.sort(key=lambda c: (c.unplaced_count, c.sheet_count, -c.utilization_pct + 0.001 * c.estimated_travel_mm))
    else:
        candidates.sort(key=lambda c: (c.unplaced_count, -c.utilization_pct, c.sheet_count))

    for rank, c in enumerate(candidates, start=1):
        c.candidate_index = rank
    return candidates


def validate_sheet_placement(
    placed_items: List[Dict[str, Any]],
    sheet_width_mm: float,
    sheet_height_mm: float,
    edge_margin_mm: float,
    part_gap_mm: float,
    kerf_mm: float,
) -> Dict[str, Any]:
    """Validates a manual or automatic sheet layout against sheet boundaries, margins, and clearances."""
    usable = box(edge_margin_mm, edge_margin_mm, sheet_width_mm - edge_margin_mm, sheet_height_mm - edge_margin_mm)
    min_clearance = part_gap_mm + kerf_mm
    errors: List[str] = []
    geoms: List[Tuple[int, Polygon | MultiPolygon]] = []

    for item in placed_items:
        g = shapely_wkt.loads(item["placed_wkt"])
        pid = item["id"]
        if not usable.buffer(1e-3).contains(g):
            errors.append(f"Part placement #{pid} violates sheet boundary or {edge_margin_mm}mm edge margin.")
        geoms.append((pid, g))

    for i in range(len(geoms)):
        id_a, ga = geoms[i]
        for j in range(i + 1, len(geoms)):
            id_b, gb = geoms[j]
            dist = ga.distance(gb)
            if dist < min_clearance - 0.05:
                errors.append(
                    f"Parts #{id_a} and #{id_b} violate minimum clearance ({dist:.2f}mm < {min_clearance:.2f}mm)."
                )

    return {"valid": len(errors) == 0, "errors": errors}
